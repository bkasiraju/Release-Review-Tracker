'use strict';
/* PRIVATE point-in-time snapshot of HPS + T&I FY27 V2MOM measure names (git-ignored; ships only in the deploy zip). Used when the live sheet read fails. */
module.exports = {
 "fetchedAt": "2026-11-20",
 "measures": {
  "HPS 6.1": {
   "title": "Hyperforce Adoption Maturity",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M6"
  },
  "HPS 6.1.1": {
   "title": "Hyperforce Foundation developer experience for effective delivery of paved paths in AWS (Commercial, GovCloud, and Top Secret), GCP, and Ali",
   "owner": "Paul Constantinides Yevgeniy Geyfman (TPM)",
   "xref": "T&I 7.1.1",
   "label": "HPS FY27 V2MOM",
   "tab": "M6"
  },
  "HPS 6.1.2": {
   "title": "Hyperforce Paved Paths available in AWS (Commercial, GovCloud, and Top Secret), GCP, and Ali. Versioned paved paths deployed all environments consistently, declared timeline for versioned deployment per environment. Build automation consistently deployed in al",
   "owner": "Paul Constantinides Yevgeniy Geyfman (TPM)",
   "xref": "T&I 7.1.2",
   "label": "HPS FY27 V2MOM",
   "tab": "M6"
  },
  "HPS 6.2": {
   "title": "Managed Services Expansion",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M6"
  },
  "HPS 6.2.1": {
   "title": "Increase FKP/Mesh adoption from 71% to 90% of service instances by onboarding Einstein/Hawking(Q2), Big Data (Q2), RADX (Q3, and except for FIT/Spinaker), SCRT CSaaS/Agentforce in Prod(Q3), and Data Cloud (Control Plane in Prod in Q4) and sunset non-FKP suppor",
   "owner": "Sriram Ranganathan Srikanth Rajan",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M6"
  },
  "HPS 6.2.2": {
   "title": "Achieve 100% VegaCache adoption for caching use-cases in GCP (Agentforce, Data 360, Service Cloud) and >50% adoption in AWS",
   "owner": "Amit Kumar",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M6"
  },
  "HPS 6.2.3": {
   "title": "Deliver Capstone as the managed multi-substrate LOB store for near-core services:",
   "owner": "Mallikarjun (Malli) Murag",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M6"
  },
  "HPS 6.2.4": {
   "title": "Deliver MAPS as Queueing and Async Execution Platform for SCRT2 (1B/hr scale), Media Service and other non-core use-cases.",
   "owner": "Amit Kumar",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M6"
  },
  "HPS 6.3": {
   "title": "Foundation Runtime Platformization",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M6"
  },
  "HPS 6.3.3": {
   "title": "FKP v2 subset capabilities for tenant registration, self-serve nodepool configuration, integration management available in all existing FIs for self-serve onboarding/customization, improved operational excellence by Q3",
   "owner": "Srikanth Rajan Sana Jawad",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M6"
  },
  "HPS 6.3.4": {
   "title": "Accelerate Near Core products like Agentforce, SCRT2, Thunderbird by providing enhanced traffic routing, observability, tenant rate limiting, near-core authN/Z capabilities and tenant aware egress callouts for near-core by Q4",
   "owner": "Srikanth RajanGloria Yu",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M6"
  },
  "HPS 6.4": {
   "title": "Foundation Security",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M6"
  },
  "HPS 6.4.1": {
   "title": "Enforce AuthN/Z for all ingress endpoints by Q4.",
   "owner": "Srikanth RajanBen Zimmerman Rama Chavali",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M6"
  },
  "HPS 6.4.2": {
   "title": "Extending Hyperforce Platform for Untrusted Code",
   "owner": "Ben Zimmerman Srikanth Rajan Stephen Waid",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M6"
  },
  "HPS 6.5": {
   "title": "Operational Excellence (incl AI Ops)",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M6"
  },
  "HPS 6.5.1": {
   "title": "Karpenter rollout for intelligent, on-demand node provisioning and deliver self-serve nodepool customization, including disruption controls, by early FY27, manage instance types, automatically upgrade instance families for 80% of workloads and optimize node al",
   "owner": "Sana Jawad",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M6"
  },
  "HPS 1.1": {
   "title": "Agentic Engineering Transformation",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.1.1": {
   "title": "Scale organizational resilience by embedding AI into role-specific workflows, achieving [20]% of total work items delivered via AI-augmentation by Q4, as measured against the quantified AI impact on Core Functional Workflows, token utilization, and workflow te",
   "owner": "Zohar Mann Cynthia (CTam) Tam",
   "xref": "T&I 2.3.1",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.1.2": {
   "title": "AI-Native Team Experiments:",
   "owner": "Aakash Srinivasan",
   "xref": "T&P 13.1.1",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.1.3": {
   "title": "AI Community of Practice - We create a forum to enable engineering teams within HPS to collaborate and showcase their AI innovation. We hold AI demos on a semi-yearly basis. We hold (at least) monthly meetings to bring the community together to share learnings",
   "owner": "Zohar Mann Isabella Ray",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.2": {
   "title": "GIS Improvements",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.2.1": {
   "title": "Engagement: 82%+ engaged as measured through GIS",
   "owner": "Brian Davis",
   "xref": "T&P 2.1.2",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.2.2": {
   "title": "Increase GIS Inclusion Index Score to company-wide goal of 90%; emphasizing psychological safety across the global org.",
   "owner": "Brian Davis",
   "xref": "T&P 2.1.3",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.2.3": {
   "title": "3ppt+ improvement (or achieve 70%+) on GIS item: 'Overall, I feel that my career goals can be met at Salesforce\" through corporate development program participation and focused Training L&D/TPIL initiatives.",
   "owner": "Brian Davis",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.2.4": {
   "title": "Mentorship, Coaching and Feedback - 3ppt+ improvement (or acheive 85%+) on GIS items:",
   "owner": "Brian Davis",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.3": {
   "title": "Removing Red Tape and Bureaucracy",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.3.1": {
   "title": "Improve Get Job Done without Bureaucracy from 57% to 63% in collaboration with sub-clouds",
   "owner": "All Paul directs",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.3.2": {
   "title": "ADS:",
   "owner": "George Yao",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.3.3": {
   "title": "HRP: Improve “Get Job Done without Bureaucracy” score from 57% to 63%",
   "owner": "Sachin Garg",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.3.4": {
   "title": "SDB:",
   "owner": "Roy Chowdhuri",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.3.5": {
   "title": "HCC:",
   "owner": "Murthy Chintalapati",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.4": {
   "title": "Connection & Community",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.4.1": {
   "title": "Strengthen leadership transparency by committing each L4 Direct (HPS level) to host 1 intimate AMA or 'Voice of the Engineer' Roundtable per quarter, ensuring a consistent and direct two-way dialogue between the Infrastructure LT and their global teams.",
   "owner": "Josh Busse Kelly Cooper",
   "xref": "T&I 2.2.1",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.4.2": {
   "title": "Focus on Connection across T&I by holding cross org social events in our major hubs including SF, Dublin, Hyderabad, at least once a year (around townhalls).",
   "owner": "Josh Busse Kelly Cooper",
   "xref": "T&I 2.1.5",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.5": {
   "title": "Customer Engagement",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.5.1": {
   "title": "Sev0/Sev1 incidents with >15 Customer Requests for Tech Executives enablement plan established within 48 hours of an incident in partnership with AESO/CAPS",
   "owner": "HPS Ops and Product Managers",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.5.2": {
   "title": "100% of Eligible VP+ are trained on Sev0 Customer Call Rotation (EoFY26: 21% or 10 of 46) and On Call Rotation schedule is equitable among eligible population.",
   "owner": "HPS Ops, Juliette McGrath",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.5.3": {
   "title": "100% of Eligible Sr. Director are trained on the Tech On-Call Rotation (EoFY26: xx%) and schedule is equitable among eligible population.",
   "owner": "HPS Ops, Deborah Donoghue",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.6": {
   "title": "Product Management Productivity & Excellence",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.6.1": {
   "title": "Product Manager AI Fluency",
   "owner": "Karishma Lalwani Manish Chandra Vish Kalsi",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.6.2": {
   "title": "Product Conferences",
   "owner": "Karishma Lalwani",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.6.3": {
   "title": "PM Excellence",
   "owner": "Karishma Lalwani Manish Chandra Vish Kalsi",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.7": {
   "title": "Innovation & Patents",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.7.1": {
   "title": "Patent Submission and Approval - 70 patents for FY27 with a 50% approval rate (FY26 x% )",
   "owner": "Olu Obembe Swaroop Jayanthi",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.7.2": {
   "title": "Agentic Patent Drafting and Process Improvement - Implement patent agents to streamline patent drafting process, increasing quality, approval rate, and reducing overhead.",
   "owner": "Olu Obembe Swaroop Jayanthi",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.8": {
   "title": "Leadership Impact",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.8.1": {
   "title": "Maintain Org Health and structural integrity by building fit-for-purpose org designs, shapes, and structures that adhere to L4 corporate and functional % targets.",
   "owner": "Paul + Directs + Brian Davis",
   "xref": "T&I 2.2.2",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.8.2": {
   "title": "Retain 95% of top talent through focused talent reviews and individualized and targeted engagement conversations and actions.",
   "owner": "Brian Davis + Directs",
   "xref": "T&I 2.2.3",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.8.3": {
   "title": "Fortify the leadership pipeline through semi-annual succession planning reviews for critical roles resulting in specific development to future-proof our talent.",
   "owner": "Brian Davis + Directs",
   "xref": "T&I 2.2.4",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.8.4": {
   "title": "Empower and expect managers to be talent multipliers who drive performance excellence through the high-quality execution of the annual employee performance journey; ensuring 100% completion of Quarterly check-ins, Performance Reviews, Talent Assessments, etc. ",
   "owner": "Brian Davis + Directs",
   "xref": "T&I 2.2.5",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.9": {
   "title": "Learning & Compliance",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.9.1": {
   "title": "Maintain 100% organizational compliance on all corporate mandates (including mandatory training, and V2MOM reporting, Agent blazer, Corporate certifications) to safeguard operational integrity and governance.",
   "owner": "Ops",
   "xref": "T&I 2.1.1",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.10": {
   "title": "VTO",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.10.1": {
   "title": "75% participation in VTO",
   "owner": "Bianca Curley Josh Busse",
   "xref": "T&I 2.1.4",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.11": {
   "title": "Recognition",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 1.11.1": {
   "title": "50+ nominations (minimum 4 per sub-cloud) for HPS Awards each release",
   "owner": "Kelly Cooper",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M1"
  },
  "HPS 2.1": {
   "title": "Trust as our foundation - Always secure",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M2"
  },
  "HPS 2.1.1": {
   "title": "100% of P0-P1 production impact security bugs are closed with in SLA (T&P target 90%)",
   "owner": "All Paul directs",
   "xref": "T&P 1.02",
   "label": "HPS FY27 V2MOM",
   "tab": "M2"
  },
  "HPS 2.1.2": {
   "title": "HPS meets GIA2H 3PP SLA compliance across all clouds/teams to reduce vulnerability exposure and meet complaince requirements",
   "owner": "All Paul directs",
   "xref": "T&P 1.04",
   "label": "HPS FY27 V2MOM",
   "tab": "M2"
  },
  "HPS 2.1.3": {
   "title": "HPS meets defined 99% Infra patching for P0-P1 Vuls across 1P & Hyperforce & GIA2H and BlackJack",
   "owner": "All Paul directs",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M2"
  },
  "HPS 2.2": {
   "title": "Trust as our foundation - Always Available",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M2"
  },
  "HPS 2.2.1": {
   "title": "All services detect any Sev 0/1 incident within 5 minutes (TTD), and reduce P75 TTR time by 50%.",
   "owner": "All Paul directs",
   "xref": "T&P 1.03",
   "label": "HPS FY27 V2MOM",
   "tab": "M2"
  },
  "HPS 2.2.2": {
   "title": "[ Incident response ]",
   "owner": "All Paul directs",
   "xref": "T&P 1.34",
   "label": "HPS FY27 V2MOM",
   "tab": "M2"
  },
  "HPS 2.2.3": {
   "title": "[Availability]: All Tier0-1 HPS services complete at least one HARR review annually. 100% of P0-P1 availability backlogs (identified through HARR , PRBs and Chaos tests) are remediated with in SLAs",
   "owner": "All Paul directs",
   "xref": "T&P 1.03",
   "label": "HPS FY27 V2MOM",
   "tab": "M2"
  },
  "HPS 2.2.4": {
   "title": "[100% Safe Change at Scale] All Services exit MD, No manual changes and all changes meet Safe Change criteria. All exceptions require Paul's approval.",
   "owner": "All Paul directs",
   "xref": "T&P 1.12",
   "label": "HPS FY27 V2MOM",
   "tab": "M2"
  },
  "HPS 2.3": {
   "title": "Trust as our foundation - Quality",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M2"
  },
  "HPS 2.3.1": {
   "title": "[Quality SLAs]",
   "owner": "All Paul directs",
   "xref": "T&P 1.17",
   "label": "HPS FY27 V2MOM",
   "tab": "M2"
  },
  "HPS 2.3.2": {
   "title": "[Release Quality] Reduce Sev0/Sev1 All Core/Near/Off-Core repeat incidents by >50%",
   "owner": "All Paul directs",
   "xref": "T&P 1.17",
   "label": "HPS FY27 V2MOM",
   "tab": "M2"
  },
  "HPS 2.3.3": {
   "title": "All tier0/tier1 service have 1) SLAs published and 2) regular (every release/quarter) scale, performance and chaos tests executed 3) meet auto scaling, AZ resiliency requirements",
   "owner": "All Paul directs",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M2"
  },
  "HPS 2.3.4": {
   "title": "[ Accessibility]: Address P01 A11Y Bugs with a 30 day SLA by end of Q2 and P2 A11Y Bugs with a 90 day SLA by EOY with maximum 10% extension. Bugs with customer cases closed within Customer bugs SLA and maximum 5% SLA extension.",
   "owner": "All Paul directs",
   "xref": "T&P 1.36",
   "label": "HPS FY27 V2MOM",
   "tab": "M2"
  },
  "HPS 2.4": {
   "title": "Risk Registers",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M2"
  },
  "HPS 2.4.1": {
   "title": "Quarterly review of all Risks (security , infra and availability), actionable Risks are remediated based on agreed plan",
   "owner": "David Ho",
   "xref": "T&P 1.16",
   "label": "HPS FY27 V2MOM",
   "tab": "M2"
  },
  "HPS 2.4.2": {
   "title": "Security & Availability Risk Register",
   "owner": "All Paul directs",
   "xref": "T&I 1.5",
   "label": "HPS FY27 V2MOM",
   "tab": "M2"
  },
  "HPS 2.4.3": {
   "title": "HPS Risk Register process and governance to ensure leadership visibility",
   "owner": "David Ho Ashley Roosevelt Vanessa Homewood (she/her)",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M2"
  },
  "HPS 2.5": {
   "title": "Toil Reduction & Eliminate Systematic Blockers",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M2"
  },
  "HPS 2.5.1": {
   "title": "Build Automation: All services achieve 100% automated build and destroy operations in Hyperforce by March 31; any service with manual steps for build or destroy after 3/31 is blocked from doing those respective operations in production.",
   "owner": "Wolfgang Krause Ashley Roosevelt",
   "xref": "T&P 1.24",
   "label": "HPS FY27 V2MOM",
   "tab": "M2"
  },
  "HPS 2.6": {
   "title": "From Tribal Knowledge to Codified Intelligence — Skill Libraries for Prevention and Resolution",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M2"
  },
  "HPS 2.6.1": {
   "title": "Prevention — Shift Architectural Defect Detection from Production to PR Time. Reduce production SEV 0/1 incidents caused by known anti-pattern classes by enforcing AI-powered detection as a merge gate.",
   "owner": "Brian Toal",
   "xref": "T&P 1.03, 1.12 Meir 5.1.2",
   "label": "HPS FY27 V2MOM",
   "tab": "M2"
  },
  "HPS 2.6.2": {
   "title": "Resolution — Reduce Incident Triage and Resolution Time Through Operational Skill Libraries",
   "owner": "Brian Toal",
   "xref": "T&P 1.03, 1.12 Meir 5.1.2",
   "label": "HPS FY27 V2MOM",
   "tab": "M2"
  },
  "HPS 3.1": {
   "title": "AZ Failure Resilence",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M3"
  },
  "HPS 3.1.1": {
   "title": "FKP ensures tier0/1 stateless services have no more than 10% AZ skew for AZ failure resilience by Q4",
   "owner": "Srikanth Rajan Uttam Kumar",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M3"
  },
  "HPS 3.1.2": {
   "title": "FKP - to prevent incidents due to in sufficient capacity enable MiTP feature by default to allow customers utilize available types of hardware by end of Q2",
   "owner": "Srikanth RajanSana Jawad",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M3"
  },
  "HPS 3.2": {
   "title": "Safe Change",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M3"
  },
  "HPS 3.2.1": {
   "title": "FKP & Integrations Safe Change",
   "owner": "Srikanth Rajan Stephen Waid",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M3"
  },
  "HPS 3.3": {
   "title": "Service Protection",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M3"
  },
  "HPS 3.3.1": {
   "title": "Global Rate Limiting Service (GRLS) baked-in into all Service Mesh, automated local rate-limiting enabled for 100% of Mesh-based services to prevent sev0/1/2 overload incidents and ensuring infrastructure resilience by end of FY27",
   "owner": "Tony Wong",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M3"
  },
  "HPS 3.3.2": {
   "title": "Core surge protection: Provide real-time Core surge detection and protection from vulnerabilities exposed in help.salesforce.com Sev0 incident. Integration with DREAM by Q2 and address address low-volume malicious attacks by Q3, unauthenticated requests satura",
   "owner": "Daeki Cho Santhosh Manohar Tony Wong Sanjeev Chhabria Prabhat Singh Jason Woods",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M3"
  },
  "HPS 3.4": {
   "title": "Warden AIOps: Seamless Onboarding Experience Adoption by Tier 0 & Tier 1 services in A&IE and HPS foundation services , with high blast radius, to drive 4 9s availability with measurable improvements for TTD and TTR",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M3"
  },
  "HPS 3.4.1": {
   "title": "[Pilot] Onboard 5 Tier 0 / Tier 1 A&IE & HPS foundation services to Warden AIOps and improve Incident SLOs (TTD, TTR) by 30% [H1]",
   "owner": "Karishma Lalwani Laksh Venka Jeff Stammler",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M3"
  },
  "HPS 3.4.2": {
   "title": "[GA] Onboard all Tier 0 / Tier 1 A&IE & HPS foundation services to Warden AIOps to achieve TTD < 10 min & TTR < 30 min [H2]",
   "owner": "Karishma Lalwani Laksh Venka Jeff Stammler",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M3"
  },
  "HPS 3.4.3": {
   "title": "Warden AIOps: Transparent Analytics for Tier 0/1 Services",
   "owner": "Karishma Lalwani Laksh Venka Jeff Stammler",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M3"
  },
  "HPS 3.4.3.1": {
   "title": "Provide 100% of onboarded Tier 0/1 services with access to unified AIOps analytics dashboards [Q2]",
   "owner": "Karishma Lalwani Laksh Venka Jeff Stammler",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M3"
  },
  "HPS 3.4.3.2": {
   "title": "Integrate 100% of standardized Warden AIOps attribution and standardized impact analytics for Tier 0/1 onboarded services with Engg360 [H2 Q4]",
   "owner": "Karishma Lalwani Laksh Venka Jeff Stammler",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M3"
  },
  "HPS 3.5": {
   "title": "<NEW April 2026> Global Out-of-Region Data Durability & Geo-Policy Enforcement: Achieve 100% Global Out-of-Region Data Durability with automated geographical policy enforcement across all regional segments (G1–G5) by end of FY27.",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M3"
  },
  "HPS 3.5.1": {
   "title": "Updated July 2026",
   "owner": "Subho Chatterjee (Primary) Herman Kwong Fiaz Hossain Manish Chandra Mallikarjun (Malli) Murag (FFX)Alberto Valcarlos(TPM",
   "xref": "T&I 1.24",
   "label": "HPS FY27 V2MOM",
   "tab": "M3"
  },
  "HPS 4.1": {
   "title": "Core Customer Ramp to Hyperforce (CCR2HF)",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.1.1": {
   "title": "CCR2HF: 100% of Core prod orgs on Hyperforce by EoQ3, except for AWS-averse, ACRC-Roadmap and T&P exceptions (Q1: 99.2%; Q2: 99.4%; Q3: 99.5%; Q4: 99.7%)",
   "owner": "Sridevi Gopala Krishnan Andrea Loster Soumya Roy",
   "xref": "T&I 6.1.1",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.1.2": {
   "title": "CCR2HF: 10% of AWS-averse Core prod orgs migrated to Hyperforce-GCP by EoFY27, including some orgs from Alphabet and Walmart",
   "owner": "Sridevi Gopala Krishnan Andrea Loster Soumya Roy",
   "xref": "T&I 6.1.2",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.1.3": {
   "title": "Eligibility: No new downselect for 1P -> HF (GCP & AWS) in FY27 and all services must comply with Core tenant (Org) Mobility requirements",
   "owner": "Pallavi Chauhan",
   "xref": "T&I 6.1.3",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.1.4": {
   "title": "Eligibility: 100% of legally ineligible customers are eligible for HF migrations by EoQ1",
   "owner": "Pallavi Chauhan",
   "xref": "T&I 6.1.4",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.1.5": {
   "title": "Eligibility: Resolve and Remove Alternative MyDomains and TLS Encryption BofA downselect by June 1, 2026",
   "owner": "Pallavi Chauhan",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.1.6": {
   "title": "Eligibility: Resolve and Remove Advanced Cross Region Continuity (ACRC) downselects per the roadmap below:",
   "owner": "Alberto Valcarlos Manish Chandra Subho Chatterjee",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.1.7": {
   "title": "Migration: Stagger rollout of org migration from 1P->GCP beginning in June. First external customer migrations in September",
   "owner": "Intisar Malhi",
   "xref": "T&I 6.1.5",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.1.8": {
   "title": "Migration: Sandbox routing and environment creation for 1P customers ready by July 1",
   "owner": "Intisar Malhi",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.1.9": {
   "title": "Migration: Stagger rollout of org migration from AWS->GCP beginning with 264 SB0 in mid-August.",
   "owner": "Intisar Malhi",
   "xref": "T&I 6.1.6",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.1.10": {
   "title": "Migration: Sandbox routing and environment creation for AWS customers, ready for testing with SB0 in mid-August",
   "owner": "Intisar Malhi",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.1.11": {
   "title": "Migration: Stagger rollout of org migration from GCP to AWS beginning in February",
   "owner": "Intisar Malhi",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.1.12": {
   "title": "Migration: Sandbox routing and environment creation for GCP to AWS customers ready by February",
   "owner": "Intisar Malhi",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.1.13": {
   "title": "Non-Revenue Orgs: 90% of eligible non-revenue orgs migrated to Hyperforce by EoFY27 (plan)",
   "owner": "Intisar Malhi",
   "xref": "T&I 6.1.7",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.1.14": {
   "title": "Revenue-Potential Signups: Route 100% AWS-averse revenue-potential sign-ups in NA on HF-GCP by EoQ4.",
   "owner": "Vamsi Korlepara Dileep Burki Katie Fuller Itay Levi Joe Francis",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.2": {
   "title": "ECom to Hyperforce",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.2.1": {
   "title": "Exit Progress - 10 realms migrated by end of Q1",
   "owner": "Greg Guadagnolo Nick Martz John Zhao Obie Egwim",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.2.2": {
   "title": "Exit Progress - 50 realms (aggregate) by end of Q2",
   "owner": "Greg Guadagnolo Nick Martz John Zhao Obie Egwim",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.2.3": {
   "title": "Exit Progress -100 realms (~5% of storefronts) migrated before the holiday moratorium (November 2026)",
   "owner": "Greg Guadagnolo Nick Martz John Zhao Obie Egwim",
   "xref": "T&I 6.3.1",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.2.4": {
   "title": "Capabilities - Support 40 realm/month migration velocity by end of FY",
   "owner": "Greg Guadagnolo Nick Martz John Zhao Obie Egwim",
   "xref": "T&I 6.3.2",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.2.5": {
   "title": "Capabilities - Design for HF to HF migrations in Q4 FY27",
   "owner": "Greg Guadagnolo Nick Martz John Zhao Obie Egwim",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.2.6": {
   "title": "Validate Platinum URC on Hyperforce by December. Five Platinum realms planned for February 2027 migration.",
   "owner": "Greg Guadagnolo Bharath Venkatakrishnan Anand Lakshminath",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.3": {
   "title": "Core 1P Consolidation",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.3.1": {
   "title": "Consolidate first-party footprint from 140 to 65 pods by Q4 FY27, advancing toward the target of 50 pods in Q1 FY28. This consolidation will generate $77M in total restructuring savings: $19M in FY27, $42M in FY28, and $16M in FY29",
   "owner": "George Yao Katie Wakim Pallavi Chauhan",
   "xref": "T&I 6.5.1",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.3.2": {
   "title": "Reduce number of 1P pods for APAC (IT4/HN4) from 18 to 9 in by EoFY27",
   "owner": "George Yao Katie Wakim Pallavi Chauhan",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.3.3": {
   "title": "EU - Reduce number of 1P pods for AR3/AM3 from 20 to 7 by EoFY27",
   "owner": "George Yao Katie Wakim Pallavi Chauhan",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.3.4": {
   "title": "NA - Reduce number of 1P pods for IA6/IA7 from 82 to 49 by EoFY27 by evacuating SP1 and consolidating SP2, SP3 & SP4",
   "owner": "George Yao Katie Wakim Pallavi Chauhan",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.4": {
   "title": "FFX Data Evacuation",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.4.1": {
   "title": "IT3 / HN3 - 100% of production org FFX data evacuated from IT3/HN3 by EO Aug 2026 (within 2 sprints following the final PMD)",
   "owner": "Mallikarjun (Malli) Murag Kathryn Benson",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.4.2": {
   "title": "IT3 / HN3 - 100% of sandbox org FFX data evacuated from IT3/HN3 by EO Nov 2026 (within 6 sprints following prod 4.1.2 completion)",
   "owner": "Mallikarjun (Malli) Murag Kathryn Benson",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.4.3": {
   "title": "IA6 / IA7 SP1 decom: Prioritize down host recovery velocity from managed reserve for IA6/IA7 SP3 CapAdd completion by EO July 2026 in preparation for PMDs in August 2026.",
   "owner": "Mallikarjun (Malli) Murag Kathryn Benson",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.5": {
   "title": "1P Decomm",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.5.1": {
   "title": "1P Core Decommission / DC Exits - Decom Core in IA4/IA5 - Q1 FY27",
   "owner": "Alsontra Daniels Nishant Gupta (CECM) Jamie Barton",
   "xref": "T&I 6.6.1",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.5.2": {
   "title": "1P Core Decommission / DC Exits - Decom IT3/HN3",
   "owner": "Alsontra Daniels Nishant Gupta (CECM) Jamie Barton",
   "xref": "T&I 6.6.1",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.5.3": {
   "title": "1P Core Decommission / DC Exits - Decom RZ1 in PHX3 by Q3 FY27",
   "owner": "Alsontra Daniels Nishant Gupta (CECM) Jamie Barton",
   "xref": "T&I 6.6.1",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.5.4": {
   "title": "1P Consolidation and Restructure - Finalize the 1P asset restructure process and implement tooling enhancements in Q1 FY27",
   "owner": "Alsontra Daniels Nishant Gupta (CECM) Jamie Barton",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.5.5": {
   "title": "1P Consolidation and Restructure - Logical Decomm after Intra-Kingdom Pod Consolidations",
   "owner": "Alsontra Daniels Nishant Gupta (CECM) Jamie Barton",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.6": {
   "title": "Hyperforce Core Infrastructure Consolidation",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.6.1": {
   "title": "Evac & Decom Cells - Evacuate & decommission 31 obsolete Core cells within their FD to ensure efficient fleet utilization as infrastructure and workload placement evolve",
   "owner": "Katie Fuller Suresh Subramanian Xinwei Jin Raksha Subramanyam Charlotte Doud",
   "xref": "T&I 6.8.1",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.6.2": {
   "title": "Automation - Deliver capability to reshape Hyperforce Infrastructure through fully automated cell evacuation and decomm. Pilot fully automated evacuation & decomm of 3 Production and 1 Sandbox cells in FY27Q4.",
   "owner": "Katie Fuller Suresh Subramanian Xinwei Jin Raksha Subramanyam Charlotte Doud",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.6.3": {
   "title": "Decomm FD - Decomm Prod3/Core2eoz FD to drive upwards of $160K/month CTS Savings by end of Q4 Q2",
   "owner": "Katie Fuller Suresh Subramanian Xinwei Jin Raksha Subramanyam Charlotte Doud",
   "xref": "T&I 6.8.2",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.7": {
   "title": "Dynamic Org Placement",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.7.1": {
   "title": "Migrations - By the end of FY27, 75% of intra-FD migrations executed in 15-min communicated read-only windows, 60% of signup conversion migrations completed in <30s, and technical roadmap validated to scale intra-FD core org migrations to 100% <30s execution i",
   "owner": "Intisar Malhi Haiyan Du Raksha Subramanyam Charlotte Doud",
   "xref": "T&I 6.7.1",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.8": {
   "title": "Hyperforce New Region Expansion",
   "owner": "",
   "xref": "6.4",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.8.1": {
   "title": "AWS Commercial (1P Exit) - AWS/Prod27 (US East 1) first MOM by March 2026",
   "owner": "Pallavi Chauhan Manish Chandra Nishant Gupta (CECM)",
   "xref": "T&I 6.4.1",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.8.2": {
   "title": "GCP Commercial (1P Exit) - GCP/Prod2 (Berlin) build start to support Q1 FY28 MOMs",
   "owner": "Pallavi Chauhan Manish Chandra Nishant Gupta (CECM)",
   "xref": "T&I 6.4.1",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.8.3": {
   "title": "GCP Commercial (1P Exit) - GCP/Prod3 (Osaka) build start to support Q3 FY28 MOMs",
   "owner": "Pallavi Chauhan Manish Chandra Nishant Gupta (CECM)",
   "xref": "T&I 6.4.1",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 4.8.4": {
   "title": "AWS Commercial (FI Rebalancing) - AWS/Prod28 (US West 2) first MOM by June 2026",
   "owner": "Pallavi Chauhan Manish Chandra Nishant Gupta (CECM)",
   "xref": "T&I 6.4.2",
   "label": "HPS FY27 V2MOM",
   "tab": "M4"
  },
  "HPS 5.1": {
   "title": "Hyperforce on GCP Business Delivery",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M5"
  },
  "HPS 5.1.1": {
   "title": "GCP EGL Core Availability: Achieve External Go Live ( EGL ) by 7/1/2026",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M5"
  },
  "HPS 5.1.2": {
   "title": "SCRT1 and SCRT2 EGL and GA in GCP",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M5"
  },
  "HPS 5.2": {
   "title": "Hyperforce on GCP Production Readiness",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M5"
  },
  "HPS 5.2.1": {
   "title": "All product Clouds ( Sales, Service, Platform) complete product cloud testing and issue fixes by 6/1; All Foundation and Core service complete Q4 testing and fix performance regressions by 6/15",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M5"
  },
  "HPS 5.2.2": {
   "title": "Security scanners available and fully operational in GCP Prod by EGL (7/1 target)",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M5"
  },
  "HPS 5.2.3": {
   "title": "GCP Pilot and Org Migration Support Run Pilot and validations with SBXs/ Prod Orgs (internal and external) Jul-Oct 2026 before GA 1P-> GCP tooling available by July 1st 2026 AWS->GCP tooling in SB0 available by Aug10th 2026",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M5"
  },
  "HPS 5.3": {
   "title": "Hyperforce on GCP Product and Region Expansion",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M5"
  },
  "HPS 5.3.1": {
   "title": "Data Cloud and Agentforce architecture and roadmap for GCP defined in Q1",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M5"
  },
  "HPS 5.3.2": {
   "title": "Region Expansion:",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M5"
  },
  "HPS 5.3.3": {
   "title": "Net New Salesforce Customers onboarding to GCP Starting January 2027",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M5"
  },
  "HPS 5.3.4": {
   "title": "GCP Marketplace",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M5"
  },
  "HPS 5.4": {
   "title": "Hyperforce on GCP Architecture",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M5"
  },
  "HPS 5.4.1": {
   "title": "GCP Uplift by the delivery dates",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M5"
  },
  "HPS 5.5": {
   "title": "Fileforce Fueling Agentforce in Gov Cloud and Support BJ-J",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M5"
  },
  "HPS 5.5.1": {
   "title": "Deliver Fileforce connector for Data Cloud in GovCloud by 262.",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M5"
  },
  "HPS 5.5.2": {
   "title": "Complete the build out of Fileforce in air-gapped Blackjack-J.",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M5"
  },
  "HPS 5.6": {
   "title": "Core on GCP Production Readiness",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M5"
  },
  "HPS 5.6.1": {
   "title": "GCP - Zero-Touch Cell Core Configuration - Automation or elimination of config changes required to introduce new cell/fd or fi (remove hbase/search/sdb service discovery static config, decouple server pool, decouple ACRC config). Deliver on GCP and then backpo",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M5"
  },
  "HPS 5.6.2": {
   "title": "GCP - Core FD Management - Leverage Compute Buckets and Compute Groups to managed Core FD k8s clusters (supercells) and node pools.",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M5"
  },
  "HPS 5.6.3": {
   "title": "Core on GCP - Day 2 Operational Readiness",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M5"
  },
  "HPS 5.6.3.1": {
   "title": "Falcon Safe Change Compliance Met",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M5"
  },
  "HPS 5.6.4": {
   "title": "Core on GCP EGL Functional Complete -",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M5"
  },
  "HPS 5.6.5": {
   "title": "Drive Core on GCP SLO Compliance for Availability and Performance for go-live - Goal is to move out of first-party in North America by mid-2027 and in Japan by the end of 2028.",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M5"
  },
  "HPS 5.6.6": {
   "title": "Onboard ScaleX Services to GCP",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M5"
  },
  "HPS 5.6.7": {
   "title": "Capacity Management for GCP: Determine the equivalent of how ODCR is managed for GCP. Based on the selected instance type, start determining the initial set of reservations and timelines by Q2.",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M5"
  },
  "HPS 5.7": {
   "title": "Core App on Blackjack-J - Service Owner Entry Criteria for JProd Deployment",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M5"
  },
  "HPS 5.7.1": {
   "title": "Continue delivering Low Side Dev build to completion",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M5"
  },
  "HPS 5.7.2": {
   "title": "Meet Service Owner expectations of Blackjack J Build Team Agreement - Stage and Production",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M5"
  },
  "HPS 5.7.3": {
   "title": "Support Low Side Stage build - on call",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M5"
  },
  "HPS 5.7.4": {
   "title": "Support High Side Prod build - on call",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M5"
  },
  "HPS 5.8": {
   "title": "HFv2 - Substrate True Up - uplift in GIA2H by Q4",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M5"
  },
  "HPS 5.8.1": {
   "title": "Deliver AWS commercial Trueup (M9.5) to GIA2H environment",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M5"
  },
  "HPS 7.1": {
   "title": "Blast Radius Innovation",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M7"
  },
  "HPS 7.1.1": {
   "title": "Deliver OOB Cluster redundancy & Cellularization",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M7"
  },
  "HPS 7.2": {
   "title": "Blast Radius Reduction and Fault Tolerance",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M7"
  },
  "HPS 7.2.1": {
   "title": "Deprecate unsafe services and integrations",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M7"
  },
  "HPS 7.3": {
   "title": "Intelligent Workload Placement",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M7"
  },
  "HPS 7.3.1": {
   "title": "Tenant Mobility: On the path to all Hyperforce Services supporting Tenant Mobility Compatibility northstar:",
   "owner": "",
   "xref": "T&P 1.27 T&I 5.4.1",
   "label": "HPS FY27 V2MOM",
   "tab": "M7"
  },
  "HPS 7.3.2": {
   "title": "SWAPS - All HF services report where geographically they store data to SWAPS by Q4 for Auditable Service Colocation and Data Residency.",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M7"
  },
  "HPS 7.3.3": {
   "title": "Core Org Mobility - Reduce customer communicated read-only maintenance period for cross-FI Core org migrations to 60 minutes by Q3, 30 minutes by Q4",
   "owner": "",
   "xref": "T&I 11.2.3",
   "label": "HPS FY27 V2MOM",
   "tab": "M7"
  },
  "HPS 7.3.4": {
   "title": "AOV Balancing - All FIs have C360 AOV less than $4B by Q4 FY27.",
   "owner": "",
   "xref": "T&I 11.2.3",
   "label": "HPS FY27 V2MOM",
   "tab": "M7"
  },
  "HPS 7.3.5": {
   "title": "AOV Balancing - Move at least 90% of eligible a minimum of 35% of India FINS AOV from prod2 Mumbai to prod24 Hyderabad by Q4",
   "owner": "",
   "xref": "T&I 11.2.4",
   "label": "HPS FY27 V2MOM",
   "tab": "M7"
  },
  "HPS 7.3.6": {
   "title": "AOV Balancing - Balance Core AOV across incremental FIs in each of the following countries: Australia, UK, USA, France, and Germany such that Technology, Financial Services, Manufacturing, and Healthcare AOV is evenly spread across FIs within those four countr",
   "owner": "",
   "xref": "T&I 11.2.5",
   "label": "HPS FY27 V2MOM",
   "tab": "M7"
  },
  "HPS 7.3.7": {
   "title": "SWAPS - Protect SDB Cloudstore from capacity exhaustion and drive higher utilization by autonomously placing and moving workloads starting in Q4. Maintain SDB Cloudstore utilization under safe threshold of 80%.",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M7"
  },
  "HPS 8.1": {
   "title": "Trust: SDB",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M8"
  },
  "HPS 8.1.1": {
   "title": "Maintain 99.99% Availability for all tier 0 and tier 1 SDB services",
   "owner": "Roy Chowdhuri Srinivas Bhamidipati Prem Veeramani",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M8"
  },
  "HPS 8.1.2": {
   "title": "Eliminate Sev 0 incidents caused by SDB service failures by systematically strengthening resilience across Tier 0 components (Database, Store, and ZooKeeper).",
   "owner": "Haiyan Du",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M8"
  },
  "HPS 8.1.3": {
   "title": "Release Quality: Advance Proactive Testing, Rollback Confidence, and Continuous Resilience",
   "owner": "Sherman Lau",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M8"
  },
  "HPS 8.1.4": {
   "title": "Complete full adoption of Mutual Diet (MR) for all SDB features and services by Q2FY27.",
   "owner": "Santosh Pathak",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M8"
  },
  "HPS 8.1.5": {
   "title": "Significant Deployment Architecture Uplift for SDB Services in AWS: Deliver a Java Kubernetes Operator–based deployment model for all core SDB services in AWS to improve robustness, testability, and operational reliability across the production fleet by the en",
   "owner": "Santosh Pathak",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M8"
  },
  "HPS 8.2": {
   "title": "Trust:Oracle",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M8"
  },
  "HPS 8.2.1": {
   "title": "OL9 OS Uplift across Core and ECOM: Upgrade the Core & ECOM DB fleet OS from OL7 to OL9 for ensuring continued support of all the 3PPs and maintain the compliance above 99% by Q4.",
   "owner": "Srinivas Bhamidipati",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M8"
  },
  "HPS 8.2.2": {
   "title": "Hyperforce LADB Image rollout: Drive Build (OS/Kernel updates, DB RU updates, Security updates, qualification, Test and rollout across 100% of Hyperforce LA DB fleet to ensure platform currency and remediate vulnerabilities",
   "owner": "Srinivas Bhamidipati",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M8"
  },
  "HPS 8.2.3": {
   "title": "Availability : 99.99% availability across all Database Infrastructure Services (DB / System) — Core, Commerce, and Live Agent (LA)",
   "owner": "Srinivas Bhamidipati",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M8"
  },
  "HPS 8.3": {
   "title": "Performance / Scale",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M8"
  },
  "HPS 8.3.1": {
   "title": "Support 50% growth in traffic for large organization and large multi-tenanted cluster scale through architectural innovations and disaggregated compute scaling.",
   "owner": "Haiyan Du",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M8"
  },
  "HPS 8.3.2": {
   "title": "Enhance Memstore Performance by rolling out key order purge and merge enhancements: Boost throughput to prevent throttling during high-intensity workloads including large sharing recalculations, bulk deletes, and Keystone/MOM operations serving as a backstop f",
   "owner": "Rajasekhar Cherabuddi",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M8"
  },
  "HPS 8.3.3": {
   "title": "Deliver Federated Store to expand the scope of SDB Superpower (migrations, sandboxes, and database clones) beyond the current FKP cluster level to the Functional Domain (FD) level, while maintaining controlled blast radius. In cases, where needed, this capabil",
   "owner": "Ashish Mahajan",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M8"
  },
  "HPS 8.3.4": {
   "title": "Support Key Events for large orgs (e.g., Diwali and Bajaj).",
   "owner": "Andrew Brill Manindra Pandey Haiyan Du",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M8"
  },
  "HPS 8.3.5": {
   "title": "Deliver measurable improvements for the core app dynamic query performance by improved costing, data skew handling, and improved visibility stats:",
   "owner": "Parmod Mehta Jesse Collins",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M8"
  },
  "HPS 8.3.6": {
   "title": "Deliver AQT 2.0 for SDB to proactively tune 25% of incident-prone queries caused by suboptimal query plans:",
   "owner": "Parmod Mehta Aswath Sadagopan",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M8"
  },
  "HPS 8.4": {
   "title": "Support for SCRT2 and Data Cloud",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M8"
  },
  "HPS 8.4.1": {
   "title": "Enable SCRT2 to run on GCP Hyperforce by using mSDB as the backend database. Demonstrate functional parity, transactional correctness, and strong tenant isolation at scale through tenant partitioning. The projected timelines per plan is as follows:",
   "owner": "Roy Chowdhuri Nithya Muthukrishnan Mike Boz Haiyan Du",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M8"
  },
  "HPS 8.4.2": {
   "title": "SDB as the Real-Time Data Graph (RTDG) Store for Data Cloud: Deliver SDB as a purpose-built, low-latency (<10ms) transactional key/value store for Real-Time Data per plan Graphs supporting the following:",
   "owner": "Nithya Muthukrishnan",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M8"
  },
  "HPS 8.4.3": {
   "title": "mSDB Tenant mobility will be managed at the SDB layer at a FKP cluster level in FY27.",
   "owner": "Nithya Muthukrishnan Haiyan Du",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M8"
  },
  "HPS 8.5": {
   "title": "Off Core",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M8"
  },
  "HPS 8.5.1": {
   "title": "MC: Marketing Cloud",
   "owner": "Nithya Muthukrishnan",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M8"
  },
  "HPS 8.5.2": {
   "title": "ECom on SDB:",
   "owner": "Nithya Muthukrishnan",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M8"
  },
  "HPS 8.5.3": {
   "title": "ITSM:",
   "owner": "Rajasekhar Cherabuddi Scott Ware Xiaodan Wang Thomas Fanghaenel Nithya Muthukrishnan",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M8"
  },
  "HPS 8.5.4": {
   "title": "mSDB Core",
   "owner": "Nithya Muthukrishnan, Haiyan Du",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M8"
  },
  "HPS 8.5.5": {
   "title": "mSDB MultiSubstrate Support",
   "owner": "Nithya Muthukrishnan Santosh Pathak",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M8"
  },
  "HPS 8.6": {
   "title": "Advanced Cross Region Continuity (ACRC) for Core 1P Exit",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M8"
  },
  "HPS 8.6.1": {
   "title": "Advanced Cross Region Continuity (ACRC) – 1P Exit",
   "owner": "Vijay Devadhar Manish Chandra Harmeek Singh Bedi",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M8"
  },
  "HPS 8.7": {
   "title": "1P Exit for NA - Leading Edge RTO/RPO - 1 hr / 15 Min",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M8"
  },
  "HPS 8.7.1": {
   "title": "For customers such as Ally and Barclays and Tier 0 use cases (AT&T, Delta Airlines, SWA):",
   "owner": "Steven Raspudic Patrick Louie Brian Toal Eric Fox Vijay Devadhar Harmeek Singh Bedi Mallikarjun (Malli) Murag",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M8"
  },
  "HPS 8.7.2": {
   "title": "Deliver RTO ≤ 2 hours by Q2 and RTO < 1 hr by Q4",
   "owner": "Manish Chandra Harmeek Singh Bedi",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M8"
  },
  "HPS 9.1": {
   "title": "Secure & Compliant Core Runtime platform",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M9"
  },
  "HPS 9.1.1": {
   "title": "Java Compliance for all Salesforce: Accelerate secure application delivery and enhance platform reliability by deprecating obsolete JDK versions, and enable and track 100% OneJDK in Eng360 across all Java based services.",
   "owner": "Olu ObembeMurthy Chintalapati",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M9"
  },
  "HPS 9.1.2": {
   "title": "Enhanced Security Posture: Maintain quarterly One JDK,Jetty upgrades and Jakarta EE10 compliance to eliminate vulnerabilities while enabling Spring 7 migration readiness",
   "owner": "Olu ObembeMurthy Chintalapati",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M9"
  },
  "HPS 9.1.3": {
   "title": "Core Snapline Compliance Deliver 100% monthly snapline compliance upon full scrum team establishment, with 0 out-of-SLA 3PP vulnerabilities, establish library ownership/governance, enabled by AI and automation by Q4",
   "owner": "Olu ObembeMurthy Chintalapati",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M9"
  },
  "HPS 9.1.4": {
   "title": "Post-Quantum OneJDK (TLS 1.3) Deliver post-quantum crypto strength with AES-256, and hybrid key exchange for TLS 1.3 by Q4.",
   "owner": "Olu ObembeMurthy Chintalapati",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M9"
  },
  "HPS 9.1.5": {
   "title": "Java Core Runtime Transformation: Successfully complete the upgrade, testing, and begin rollout of the Core Runtime to JDK 25 by Q3 FY27.",
   "owner": "Olu ObembeMurthy Chintalapati",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M9"
  },
  "HPS 9.1.6": {
   "title": "Onboard other major cloud/service teams to OneJDK : Data Cloud, Orgfarm, Einstein, Service Cloud, Marketing Cloud, Monitoring Cloud",
   "owner": "Olu ObembeMurthy Chintalapati",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M9"
  },
  "HPS 9.1.7": {
   "title": "Customer Crypto Experience: Deliver real-time crypto visibility for TLS and certificates; translate insights into customer experiences -- crypto health, PQC readiness, and export control eligibility -- on Core and the Security Center product roadmap.",
   "owner": "Olu Obembe Murthy Chintalapati",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M9"
  },
  "HPS 9.2": {
   "title": "Achieve 100% Core Secret Management Safe Change Compliance with uptake of PLT (1P, AWS, GCP)",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M9"
  },
  "HPS 9.2.1": {
   "title": "[262] Deliver Core Secrets MVP with a dummy secret in Dev1 using PLT, and roll out with 262",
   "owner": "Olu ObembeBrian Toal Murthy Chintalapati",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M9"
  },
  "HPS 9.2.1.1": {
   "title": "[264] Enable PLT infrastructure across all supported substrates (1P, HF [AWS|GCP], GIA2H), test and validate hello world secret works as designed.",
   "owner": "Olu ObembeBrian Toal Murthy Chintalapati",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M9"
  },
  "HPS 9.2.1.2": {
   "title": "[264] Safe Secret Compliance with Fast PLT Secret Rotation emergency remediation via ECO",
   "owner": "Olu ObembeBrian Toal Murthy Chintalapati",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M9"
  },
  "HPS 9.2.1.3": {
   "title": "[264] Collect Core Secrets metadata",
   "owner": "Olu ObembeBrian Toal Murthy Chintalapati",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M9"
  },
  "HPS 9.2.1.4": {
   "title": "[264] Core Secrets Developer Guide on how they manage secrets using PLT via Managed Operation + Git Repo checkin",
   "owner": "Olu ObembeBrian Toal Murthy Chintalapati",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M9"
  },
  "HPS 9.2.1.5": {
   "title": "[264] Improve Core Secret Observability with PLT",
   "owner": "Olu ObembeBrian Toal Murthy Chintalapati",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M9"
  },
  "HPS 9.2.2": {
   "title": "[266]Migrate 100% of sandbox + production core cells from the centralized Vault to the PLT sidecar for secret management.",
   "owner": "Olu ObembeBrian Toal Murthy Chintalapati",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M9"
  },
  "HPS 9.2.3": {
   "title": "[266]Achieve 100% operational accountability by mapping every secret to a liable owner, criticality tier, and lifecycle policy, ensuring proactive rotation for all expirable credentials.",
   "owner": "Olu ObembeBrian Toal Murthy Chintalapati",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M9"
  },
  "HPS 9.3": {
   "title": "4 9s availability for Core Runtime",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M9"
  },
  "HPS 9.3.1": {
   "title": "Automation: Warden AIOps to detect > 80% Core incidents with TTD < 8mins, auto resolve > 80% with TTR < 15mins, achieve > 60% causation accuracy",
   "owner": "Ramanjit Singh",
   "xref": "Meir 5.1.2",
   "label": "HPS FY27 V2MOM",
   "tab": "M9"
  },
  "HPS 9.3.2": {
   "title": "Connection Pool Availability:",
   "owner": "Shruti Sharma Jason Woods Olu Obembe",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M9"
  },
  "HPS 9.3.3": {
   "title": "Blast radius : Supercell deployments for Core, MQ, Vegacache, Ingress Gateway targets in Falcon Commercial to minimize blast radius for BLT50 (Q4) & GTA150 (starting Q4) prioritize GTA150 by Q2",
   "owner": "Ramanjit Singh. Betty Yip(TPM)",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M9"
  },
  "HPS 9.3.4": {
   "title": "Seamless Release Experience:",
   "owner": "Murthy Chintalapati",
   "xref": "Meir 5.1.4",
   "label": "HPS FY27 V2MOM",
   "tab": "M9"
  },
  "HPS 9.3.5": {
   "title": "ComputeGroup & Pre-Warmer & MiTP:",
   "owner": "Bruno Roque Murthy Chintalapati Ramanjit Singh Betty Yip(TPM)",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M9"
  },
  "HPS 9.3.6": {
   "title": "Enable Platform Elastic Limits (From Platform Cloud): Address key customer pain points 1. Optimize Async Apex Executions with prioritization 2. Streamline Package Push Upgrades by 50% increase in throughput and 3. Migrate Async Bulk API Query Workload",
   "owner": "Tony Wong Olu Obembe Amit Kumar",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M9"
  },
  "HPS 9.3.7": {
   "title": "Standardize Core App Threading Model: Provide managed thread pool and thread pool governance using seamstress framework to auto-remediate and prevent customer impacting incidents caused by unmanaged and non-standard thread pool implementations that exhausts in",
   "owner": "Sankar Rao Bhogi Rahul Shinde Daeki Cho",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M9"
  },
  "HPS 9.3.8": {
   "title": "Deadlock prevention & Deadlock MTTD and MTTR: ensure continuous operational stability by proactively identifying and reducing deadlock risk",
   "owner": "Sankar Rao Bhogi Rahul Shinde",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M9"
  },
  "HPS 9.3.9": {
   "title": "Core App Startup & Scaleup Governance:",
   "owner": "Sankar Rao Bhogi Rahul Shinde Tyler Phong",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M9"
  },
  "HPS 9.3.10": {
   "title": "Core app Image Governance",
   "owner": "Murthy Chintalapati Tyler Phong Deepak Singhvi",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M9"
  },
  "HPS 9.3.11": {
   "title": "[262, 264] GA planned (off-peak) core releases from GDC to fully MR based standardized staggers for coreapp fleetwide releases by Q4",
   "owner": "Murthy Chintalapati Tyler Phong",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M9"
  },
  "HPS 9.3.12": {
   "title": "Core App chaos testing to improve resilience of service dependencies (hard vs soft) with degraded mode",
   "owner": "Murthy Chintalapati Brian St Clair Ramanjit Singh",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M9"
  },
  "HPS 9.3.13": {
   "title": "Multi Region : Advanced Cross Region Continuity (ACRC)",
   "owner": "Murthy Chintalapati Tyler Phong Jason Woods Shruti Sharma Amit Kumar",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M9"
  },
  "HPS 9.4": {
   "title": "Next Gen Core runtime scalability for Bajaj Diwali 2026",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M9"
  },
  "HPS 10.1": {
   "title": "Scalability products empower customers in a self service manner to improve the performance & scalability of their solutions",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M10"
  },
  "HPS 10.1.1": {
   "title": "[Product: Trust360] Deliver Report via CSM Led Motion for all Signature customers",
   "owner": "Karishma Lalwani Anand Vardhan Lokesh Bangalore",
   "xref": "Corp 1.3.a",
   "label": "HPS FY27 V2MOM",
   "tab": "M10"
  },
  "HPS 10.1.2": {
   "title": "Top 1000 Signature success Customers",
   "owner": "Kent Allison Ravi Raina Mayuresh Verma",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M10"
  },
  "HPS 10.1.3": {
   "title": "[Product: Scale Test] for KEM, GCP , Agentforce and Product Enhancements",
   "owner": "Mayuresh Verma Archana Sethuraman",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M10"
  },
  "HPS 10.1.4": {
   "title": "[Product: Scale Center] - Additional Platform Insights",
   "owner": "Ravi Raina Utpal Das Betty Yip (TPM)",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M10"
  },
  "HPS 10.1.5": {
   "title": "[Product: ApexGuru] Shift Left and integrate into developer workflows",
   "owner": "Mayuresh Verma Manpreet Singh",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M10"
  },
  "HPS 10.1.6": {
   "title": "[Product: PROM] Beyond Core expansion",
   "owner": "Kent Allison Auro Dharmapuram Betty Yip (TPM)",
   "xref": "T&I 8.6",
   "label": "HPS FY27 V2MOM",
   "tab": "M10"
  },
  "HPS 10.1.7": {
   "title": "[Product] Agentforce For Scale",
   "owner": "Ravi Raina Mayuresh Verma Apurv Bajaj Utpal Das Betty Yip (TPM)",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M10"
  },
  "HPS 10.1.8": {
   "title": "ProM alerts expansion",
   "owner": "Paymon TeyerTPM: Betty Yip",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M10"
  },
  "HPS 10.2": {
   "title": "Top Customer level CTS Improvements",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M10"
  },
  "HPS 10.2.1": {
   "title": "Org Cost to Serve Visibility",
   "owner": "Sriram Dinavahi Brian Toal Bruno Roque",
   "xref": "Meir 8.7.1",
   "label": "HPS FY27 V2MOM",
   "tab": "M10"
  },
  "HPS 10.3": {
   "title": "Lead the Agentic Enterprise Transformation via Agentforce integration with unstructured data and enhanced Sandboxes",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M10"
  },
  "HPS 10.3.1": {
   "title": "Achieve data fluidity and automatic availability of Core unstructured data in Data Cloud for RAG and Agentforce use cases, by Q4",
   "owner": "Pad Jakkahalli Mallikarjun (Malli) Murag Manish Chandra",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M10"
  },
  "HPS 10.3.2": {
   "title": "To reduce latency and storage costs associated with how Agentforce Prompt Builder accesses files stored in Keystone, enable zero-copy and large files access from Salesforce Files for Prompt Builder by 262",
   "owner": "Pad Jakkahalli Mallikarjun (Malli) Murag Manish Chandra",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M10"
  },
  "HPS 10.3.3": {
   "title": "Enable parallel file uploads for Agentforce Vibes IDE to near-core unstructured data via presigned URLs, by 264.",
   "owner": "Pad Jakkahalli Mallikarjun (Malli) Murag Manish Chandra Scott Ware",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M10"
  },
  "HPS 10.3.4": {
   "title": "Support Agentforce Vibe app development through enhanced Sandboxes with Preview Orgs - 262 Pilot; 264 Beta; 266 GA",
   "owner": "Scott Ware",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M10"
  },
  "HPS 10.4": {
   "title": "Improve Support Productivity by automating causation and insights to drive faster MTTR",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M10"
  },
  "HPS 10.4.1": {
   "title": "Deliver an agentic troubleshooting solution for Support engineers that bridges them with Service Owners’ telemetry and signals, enabling faster troubleshooting and precise escalation.",
   "owner": "Utpal Das Vineeli Uppaluri",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M10"
  },
  "HPS 10.4.2": {
   "title": "Integrate Scale Agent with In-App help agent",
   "owner": "Kent Allison Utpal Das",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M10"
  },
  "HPS 10.4.3": {
   "title": "Automate THR (Technical Health Review) experience for signature customers to improve Support productivity",
   "owner": "Dheeraj Mohan Utpal Das",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M10"
  },
  "HPS 10.5": {
   "title": "Agentic Foundation for Internal Usage",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M10"
  },
  "HPS 10.5.1": {
   "title": "Accelerate Agent Engineering: Build a framework to fast-track creation and deployment of deterministic agents, provide reference agents, reusable tools, and lifecycle management to reach <3 days for 80% of production agent onboarding by Q4 while unifying agent",
   "owner": "Jacek Becla",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M10"
  },
  "HPS 10.5.2": {
   "title": "Establish Evaluation Excellence: Implement the Unified AI Evaluation Framework (Touchstone) to automate the measurement of business impact, model accuracy, performance and quality across all production agentic workflow.\"",
   "owner": "Jacek Becla",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M10"
  },
  "HPS 11.1": {
   "title": "HPS V2MoM and Budget Alignment",
   "owner": "c",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M11"
  },
  "HPS 11.1.1": {
   "title": "Identify budget buckets for all submitted HPS V2MoM measures",
   "owner": "Ashley Roosevelt Florence Fang Sherry Lin",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M11"
  },
  "HPS 11.1.2": {
   "title": "Revisit and align V2MoM measures with the FY27 official budget grant",
   "owner": "Ashley Roosevelt Florence Fang Sherry Lin",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M11"
  },
  "HPS 11.1.3": {
   "title": "Re-align V2MoM measures with additional mid-year budget guidance (if applicable)",
   "owner": "Ashley Roosevelt Florence Fang Sherry Lin",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M11"
  },
  "HPS 11.2": {
   "title": "Meet HPS Quarterly Public Cloud Budget Targets",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M11"
  },
  "HPS 11.2.1": {
   "title": "All budget owners have clearly defined FY27 budgets by 3/31.",
   "owner": "Ashley Roosevelt Florence Fang Sherry Lin",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M11"
  },
  "HPS 11.2.2": {
   "title": "Partnering with CECM to set up HF on GCP budget/cost taxonomy and budget operation processes",
   "owner": "Ashley Roosevelt Florence Fang Sherry Lin",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M11"
  },
  "HPS 11.2.3": {
   "title": "Deliver monthly forecasts and ensure all budget owners meet quarterly budget targets.",
   "owner": "Ashley Roosevelt Florence Fang Sherry Lin",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M11"
  },
  "HPS 11.2.4": {
   "title": "Requests for additional capacity assessed against Corp/T&P priorities, infra budget, and utilization targets.",
   "owner": "Ashley Roosevelt Florence Fang Sherry Lin",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M11"
  },
  "HPS 11.3": {
   "title": "Meet Cost Efficiency Targets - L5 leader level",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M11"
  },
  "HPS 11.3.1": {
   "title": "ADS Cost Efficiencies",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M11"
  },
  "HPS 11.3.1.1": {
   "title": "Deliver CTS target detailed in FY27 budget: $0.5M",
   "owner": "Amy Hurlbut Kristine Sumi",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M11"
  },
  "HPS 11.3.1.2": {
   "title": "COIN score ≥85 by Q4 FY27 at L5 leader level, strengthening local cost ownership and behavior.",
   "owner": "Amy Hurlbut Kristine Sumi",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M11"
  },
  "HPS 11.3.2": {
   "title": "HCC Cost Efficiencies",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M11"
  },
  "HPS 11.3.2.1": {
   "title": "Deliver CTS target detailed in FY27 budget: $4.7M",
   "owner": "Bruno RoqueSriram Dinavahi Bhanu Kasiraju",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M11"
  },
  "HPS 11.3.2.2": {
   "title": "COIN score ≥85 by Q4 FY27 at L5 leader level, strengthening local cost ownership and behavior.",
   "owner": "Bruno RoqueSriram Dinavahi Bhanu Kasiraju",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M11"
  },
  "HPS 11.3.2.3": {
   "title": "Achieve a 10% unit cost reduction, excluding availability investments.",
   "owner": "Bruno RoqueSriram Dinavahi Bhanu Kasiraju",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M11"
  },
  "HPS 11.3.2.4": {
   "title": "Unused ODCR #1 - Suspend or pre-empt (internal spot market) ≥ 50% of unused ODCR by Q4 FY27.",
   "owner": "Bruno RoqueSriram Dinavahi Bhanu Kasiraju",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M11"
  },
  "HPS 11.3.2.5": {
   "title": "Unused ODCR #2 - Utilize CECM internal spot market by Q4 (dependent on CECM V2MoM to deliver this feature by Q3)",
   "owner": "Bruno RoqueSriram Dinavahi Bhanu Kasiraju",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M11"
  },
  "HPS 11.3.3": {
   "title": "HRP Cost Efficiencies",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M11"
  },
  "HPS 11.3.3.1": {
   "title": "COIN score ≥85 by Q4 FY27 at L5 leader level, strengthening local cost ownership and behavior.",
   "owner": "Anubhav Dhoot Sriram Ranganathan Jennifer Chou",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M11"
  },
  "HPS 11.3.3.2": {
   "title": "Implement safe continuous Kubernetes right-sizing automation on FKP on pre-prod by Q3 FY27 and select prod by Q4 FY27",
   "owner": "Anubhav Dhoot Sriram Ranganathan Jennifer Chou",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M11"
  },
  "HPS 11.3.3.3": {
   "title": "Node optimizations",
   "owner": "Anubhav Dhoot Sriram Ranganathan Jennifer Chou",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M11"
  },
  "HPS 11.3.3.4": {
   "title": "Reduce “Idle” compute spend (sam_reserved) on default nodepools by Q4 by reducing idle waste to 20% on target clusters (~$15M/year). Enable service owners with dedicated nodepools to reduce idle ratio to 20% (~$18M/year).",
   "owner": "Anubhav Dhoot Sriram Ranganathan Jennifer Chou",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M11"
  },
  "HPS 11.3.3.5": {
   "title": "Capture 37% of the identified $280k/week low p99 cpu util savings opportunity across HRP platform services through right-sizing or approved COIN logic change requests by Q4.",
   "owner": "Anubhav Dhoot Sriram Ranganathan Jennifer Chou",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M11"
  },
  "HPS 11.3.3.6": {
   "title": "Achieve 100% cost attribution for “Idle” compute spend for non-FKP managed nodepools to their respective owners.",
   "owner": "Anubhav Dhoot Sriram Ranganathan Jennifer Chou",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M11"
  },
  "HPS 11.3.3.7": {
   "title": "Deliver CTS target detailed in FY27 budget: $2.1M",
   "owner": "Anubhav Dhoot Sriram Ranganathan Jennifer Chou",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M11"
  },
  "HPS 11.3.3.8": {
   "title": "Achieve a 10% unit cost reduction, excluding availability investments.",
   "owner": "Anubhav Dhoot Sriram Ranganathan Jennifer Chou",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M11"
  },
  "HPS 11.3.5": {
   "title": "SDB Cost Efficiencies",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M11"
  },
  "HPS 11.3.5.1": {
   "title": "Deliver CTS target detailed in FY27 budget: $10.75M",
   "owner": "Prem Veeramani Subho Chatterjee Deepesh ChaudharyEd Kraay",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M11"
  },
  "HPS 11.3.5.2": {
   "title": "COIN score ≥85 by Q4 FY27 at L5 leader level, strengthening local cost ownership and behavior.",
   "owner": "Prem Veeramani Subho Chatterjee Deepesh ChaudharyEd Kraay",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M11"
  },
  "HPS 11.3.5.3": {
   "title": "Achieve a 10% unit cost reduction, excluding availability investments.",
   "owner": "Prem Veeramani Subho Chatterjee Deepesh ChaudharyEd Kraay",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M11"
  },
  "HPS 11.3.5.4": {
   "title": "Unused ODCR #1 - Suspend or pre-empt (internal spot market) ≥45% of unused ODCR by Q4 FY27.",
   "owner": "Prem Veeramani Subho Chatterjee Suhas AgasheEd Kraay",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M11"
  },
  "HPS 12.1": {
   "title": "UIP in GovCloud",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M12"
  },
  "HPS 12.1.1": {
   "title": "Bring the power / enablement of UIP into GovCloud - re-envisioning & re-achitecting UIP as a multi-instance offering, which is well supported in disparate environments (vs. only being a global singleton in AWS Commercial).",
   "owner": "Kishore Reddipalli",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M12"
  },
  "HPS 12.2": {
   "title": "Customer & Production Intelligence Platform (CPIP)",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M12"
  },
  "HPS 12.2.1": {
   "title": "Establish the “Customer & Production Intelligence Platform” (CPIP) as a single interface for internal teams to define and deploy curated telemetry data to Customers through Data Cloud and Core Products. Deploy CPIP in every AWS Commercial region.",
   "owner": "Kishore Reddipalli",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M12"
  },
  "HPS 12.2.2": {
   "title": "Enable Gridforce capabilities in GCP (via CPIP) to enable Core products by January 31, 2027",
   "owner": "Kishore Reddipalli",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M12"
  },
  "HPS 12.2.3": {
   "title": "Deliver $5M+ in cost savings and eliminate duplicate telemetry data ingestion and storage across AWS Prod FIs by establishing a single Common Ingestion Pipeline and consolidating all existing use cases (e.g., Gridforce) into this new approach by Q2",
   "owner": "Rahul Newaskar",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M12"
  },
  "HPS 12.2.4": {
   "title": "Deliver support for Field Service and Event Log Objects access to CPIP data through Data Cloud zero-copy Federation in beta in Q2 and GA in Q3.",
   "owner": "Kishore Reddipalli",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M12"
  },
  "HPS 12.2.5": {
   "title": "Provide broad support for Salesforce “Enhanceables” / Trusted Services (e.g. Event Monitoring) on CPIP",
   "owner": "Kishore Reddipalli",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M12"
  },
  "HPS 12.2.6": {
   "title": "Bring at least three additional customers on to CPIP by 266 Core Release",
   "owner": "Kishore Reddipalli",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M12"
  },
  "HPS 12.3": {
   "title": "Next Gen Ajna",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M12"
  },
  "HPS 12.3.1": {
   "title": "Implement a Tiered Storage architecture for Ajna Kafka and data pipeline clusters to enable complete separation of compute and storage, reduce CTS, and improve availability by eliminating EBS dependency for long-term data retention.",
   "owner": "Lynch, Garrett",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M12"
  },
  "HPS 12.3.2": {
   "title": "Selective Partitioning of Telemetry by Schema (aka “Topic per LRT”): Reduce unnecessary firehose data ingestion costs by by implementing selective schema-based partitioning for logs in separate Kafka Topics and Object Store key prefixes by the end of Q4 (see S",
   "owner": "Davidson, Paul",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M12"
  },
  "HPS 12.3.3": {
   "title": "Streaming Ingestion Metadata: Make streaming ingestion infrastructure metadata available to consuming services in production. (This is the first part of a TPWG “Phase 2” Project).",
   "owner": "Lynch, Garrett Davidson, Paul",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M12"
  },
  "HPS 12.3.4": {
   "title": "Unified Ingestion Gateway Service: Launch as a production-ready managed platform capable of supporting all streaming ingestion to Ajna services (see Streaming Ingestion Gateway Northstar). Supporting first production use case by end of Q3, all remaining Ajna P",
   "owner": "Lynch, Garrett",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M12"
  },
  "HPS 12.3.5": {
   "title": "Ajna Direct Adoption - Funnel to S3 for logs reducing Kafka foundation CTS by $1.5M",
   "owner": "Lynch, Garrett",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M12"
  },
  "HPS 12.4": {
   "title": "Data Platform - Innovation and Delivery",
   "owner": "",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M12"
  },
  "HPS 12.4.1": {
   "title": "Fully shift UIP from EMR to SF Spark (including driving and contributing to the requisite FKP uplift)",
   "owner": "Kishore Reddipalli",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M12"
  },
  "HPS 12.4.2": {
   "title": "Provide data discovery & lineage services in UIP for usability and compliance (required as legal green-lights expanded untokenized data usage)",
   "owner": "Kishore Reddipalli",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M12"
  },
  "HPS 12.4.3": {
   "title": "Save $3M across UIP & BDI via efficiency initiatives",
   "owner": "Lynch, GarrettReddipalli, Kishore",
   "xref": "",
   "label": "HPS FY27 V2MOM",
   "tab": "M12"
  },
  "T&I 1.1": {
   "title": "Security Vulnerability Identification, Prioritization & Remediation Excellence",
   "owner": "L4 Eng leaders",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M1"
  },
  "T&I 1.2": {
   "title": "Availability",
   "owner": "L4 Eng leaders with , Nishant Gupta (CAO)",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M1"
  },
  "T&I 1.3": {
   "title": "100% Safe Change at Scale",
   "owner": "Shan Appajodu , Tyson Lutz, Herman Kwong , Sriram Dinavahi",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M1"
  },
  "T&I 1.4": {
   "title": "Security & Availability Risk Register",
   "owner": "Alex Kreilein, Nishant Gupta (CAO), Evan Davis, L4 Eng Leaders",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M1"
  },
  "T&I 1.5": {
   "title": "Quality Basics",
   "owner": "Tyson Lutz , Shan Appajodu, Sanjeev Balakrishnan , with L4 Cloud Leaders, Ray Finn, Chris Kohr",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M1"
  },
  "T&I 1.6": {
   "title": "Performance",
   "owner": "Jason Ding, , L4 Eng Leaders",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M1"
  },
  "T&I 1.7": {
   "title": "Capacity",
   "owner": "Nitin T Bhat",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M1"
  },
  "T&I 1.8": {
   "title": "PRB/RCA",
   "owner": "Tyson Lutz , Kelly McCracken",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M1"
  },
  "T&I 1.9": {
   "title": "Infrastructure budget: Manage Infrastructure budget to deliver on financial plan. Each Engineering EVP has a clearly defined Infra budget and a plan to manage within that budget. Requests for additional capacity assessed against Corp priorities, infra budget, ",
   "owner": "Nitin T Bhat",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M1"
  },
  "T&I 1.10.0": {
   "title": "Build and Destroy Automation",
   "owner": "Tyson Lutz with L4 Cloud Leaders",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M1"
  },
  "T&I 1.11": {
   "title": "Improve public cloud infrastructure carbon efficiency by 3% YoY to meet our corporate Sustainability goals",
   "owner": "Nitin T Bhat",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M1"
  },
  "T&I 1.12": {
   "title": "Incident response - all service teams will actively manage on-call rotations in Pagerduty to ensure 15 minute response time, 24x7x365, on all Sev0 and Sev1 incidents (including security), or as paged by an active Incident Bridge. All SVP+ leaders to do at leas",
   "owner": "Tyson Lutz & L4 Leaders",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M1"
  },
  "T&I 1.13": {
   "title": "Accessibility SLA:",
   "owner": "L4 Leaders",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M1"
  },
  "T&I 1.14": {
   "title": "Secure & Compliant Core Runtime Platform",
   "owner": "Sriram Dinavahi, Olu Obembe",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M1"
  },
  "T&I 1.15": {
   "title": "Secure Java: Infrastructure-wide Java Runtime Security & Compliance Architecture",
   "owner": "Olu Obembe",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M1"
  },
  "T&I 1.16": {
   "title": "Industry-mandated Certificate Transformation",
   "owner": "Fiaz Hossain , Ramon Peypoch",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M1"
  },
  "T&I 1.17": {
   "title": "Voice of the Customer (VoC) - utilize post-incident findings and customer feedback to improve security posture of our products within SLA:",
   "owner": "Melissa Cazalet, Kelly McCracken , Taylor Lehmann",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M1"
  },
  "T&I 1.18": {
   "title": "Incident Commander Deputy (ICD) Agent",
   "owner": "Tyson Lutz",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M1"
  },
  "T&I 1.19": {
   "title": "Hyperforce Paved Path:",
   "owner": "Paul Constantinides, Shan Appajodu ",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M1"
  },
  "T&I 1.20": {
   "title": "Create a continuous cycle of Mutual Diet exceptions, ensuring safe change exceptions are catalogued, tracked, and continually driven towards zero. Ensure safe change platform capability gaps are tracked and we have clear accountability of the number of service",
   "owner": "Tyson Lutz",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M1"
  },
  "T&I 1.21": {
   "title": "Infra Vulns Patching",
   "owner": "L4 Eng Leaders",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M1"
  },
  "T&I 1.22": {
   "title": "Global Out-of-Region Data Durability & Geo-Policy Enforcement:",
   "owner": "Subho Chatterjee, Herman Kwong, Shane Sigler, Fiaz Hossain",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M1"
  },
  "T&I 1.23": {
   "title": "100% Safe and Secure OS Adoption",
   "owner": "Tyson Lutz",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M1"
  },
  "T&I 1.24": {
   "title": "Ensure adequate compute capacity on GCP for organic growth and migrations.",
   "owner": "Nitin T Bhat",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M1"
  },
  "T&I 1.26": {
   "title": "Frontier Strike",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M1"
  },
  "T&I 1.26.1": {
   "title": "Reduce AI-Exploitable Systemic Security Risks",
   "owner": "Melissa Cazalet",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M1"
  },
  "T&I 1.26.2": {
   "title": "Vulnerability Identification:",
   "owner": "Evan Davis",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M1"
  },
  "T&I 1.26.3": {
   "title": "High-Velocity Vulnerability Remediation:",
   "owner": "Tyler Waldo",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M1"
  },
  "T&I 1.26.4": {
   "title": "Agentic Security Operations:",
   "owner": "Kelly McCracken",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M1"
  },
  "T&I 1.26.5": {
   "title": "Frontier Strike Vulnerability Prioritization:",
   "owner": "L4 Eng Leaders",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M1"
  },
  "T&I 1.26.6": {
   "title": "Frontier Strike Risk Reduction:",
   "owner": "L4 Eng Leaders",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M1"
  },
  "T&I 1.27": {
   "title": "By end of FY27, establish ENG360 as the authoritative platform for in-scope security metrics and executive reporting across Commercial, GIA2H, and Blackjack.",
   "owner": "Melissa Cazalet",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M1"
  },
  "T&I 1.28": {
   "title": "Safe deployments at scale by Q4: 100% of Spinnaker global pipelines are deprecated, the top 30 non-Spinnaker global pipelines in Hyperforce enforce staggering, and 100% of Hyperforce production deployments progress on automated health signals.",
   "owner": "Shan Appajodu, Tyson Lutz",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M1"
  },
  "T&I 1.29": {
   "title": "One engineering-wide quality framework is live by Q4: standard quality metrics, minimum quality gates enforced before merge and production deploy, and objective Go/No-Go criteria that decide every release promotion. Integration test coverage reaches 90% for cr",
   "owner": "Shiva Nimmagadda",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M1"
  },
  "T&I 1.30": {
   "title": "Service isolation for security incidents by Q4: kill-switch playbooks are published by Nov 13, proven in a tabletop by Dec 15 (with GameDay tests in lower environments), and signed off with Security by Jan 15.",
   "owner": "Tyson Lutz, Ben Hoyt",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M1"
  },
  "T&I 2.1": {
   "title": "Trust & Culture",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M2"
  },
  "T&I 2.1.1": {
   "title": "Maintain 100% compliance on all corporate mandates, reflecting our role as the primary guardians of Salesforce’s operational integrity.",
   "owner": "Vanessa Farnsworth + Central Ops + Ops Leads",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M2"
  },
  "T&I 2.1.2": {
   "title": "Achieve GIS 82%+ Engagement, with a strategic focus on improving \"Leadership Transparency\" scores to overcome localized perception lag.",
   "owner": "Amanda Eversole",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M2"
  },
  "T&I 2.1.3": {
   "title": "Increase GIS Inclusion Index Score to company-wide goal of 90%; emphasizing psychological safety across the global org.",
   "owner": "Amanda Eversole",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M2"
  },
  "T&I 2.1.4": {
   "title": "Drive 75% VTO participation by committing 5 hours per employee annually to team-based \"giving back\" events, reinforcing our Ohana values and global commitment as a key pillar of our organizational culture",
   "owner": "Vanessa Farnsworth + Central Ops + Ops Leads + EA Team",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M2"
  },
  "T&I 2.1.5": {
   "title": "Focus on Connection across T&I by holding cross org social events in our major hubs including at least once a year (around townhalls).",
   "owner": "Vanessa Farnsworth + Central Ops + Ops Leads + EA Team + Ohana Ambassadors",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M2"
  },
  "T&I 2.2": {
   "title": "Leadership Impact",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M2"
  },
  "T&I 2.2.1": {
   "title": "Strengthen leadership transparency by committing each L4 Direct to host 1 AMA or 'All Hands per quarter, ensuring a consistent and direct two-way dialogue between the Infrastructure LT and their global teams.",
   "owner": "L4 LT + Central Ops + Ops Leads",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M2"
  },
  "T&I 2.2.2": {
   "title": "Maintain Org Health and structural integrity by building fit-for-purpose org designs, shapes, and structures that adhere to L3 corporate and functional % targets.",
   "owner": "Vanessa Farnsworth + Central Ops + Ops Leads",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M2"
  },
  "T&I 2.2.3": {
   "title": "Retain 95% of top talent through focused talent reviews and individualized and targeted engagement conversations and actions.",
   "owner": "Amanda Eversole and L4 LT",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M2"
  },
  "T&I 2.2.4": {
   "title": "Fortify the leadership pipeline through semi-annual succession planning reviews for critical roles resulting in specific development to future-proof our talent.",
   "owner": "Amanda Eversole and L4 LT",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M2"
  },
  "T&I 2.2.5": {
   "title": "Empower and expect managers to be talent multipliers who drive performance excellence through the high-quality execution of the annual employee performance journey; ensuring 98% completion of Quarterly check-ins, Performance Reviews, Talent Assessments, etc. a",
   "owner": "Amanda Eversole and L4 LT",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M2"
  },
  "T&I 2.2.6": {
   "title": "Drive fiscal discipline and structural stability by operationalizing Trust & Infrastructure headcount budget tracking in alignment with L1 Cloud allocations; deliver monthly WFC/NTE reporting and collaborate with Recruiting on hiring prioritization.",
   "owner": "Vanessa Farnsworth Taylor Coutts + Central Ops + Ops Leads",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M2"
  },
  "T&I 2.2.7": {
   "title": "Performance Management Excellence: Drive performance management integrity across all L4 organizations by ensuring 100% resolution of underperformance cases within 90 days of being identified.",
   "owner": "Vanessa Farnsworth, Amanda Eversole",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M2"
  },
  "T&I 2.2.8": {
   "title": "Establish and report micro-team count (leaders with less than 4 FTE direct reports) by L4 organization each half-year, with a reduction target set once the FY27 H1 baseline is established.",
   "owner": "Vanessa Farnsworth, Amanda Eversole",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M2"
  },
  "T&I 2.2.9": {
   "title": "Red Tape/Friction Reduction: By the end of Q4, identify, prioritize, and resolve three organization-level friction points, each with a named owner, documented action plan, and measurable improvement in efficiency, employee experience, or cross-functional colla",
   "owner": "Ben Royal, Zohar Mann",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M2"
  },
  "T&I 2.3": {
   "title": "AI Transformation",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M2"
  },
  "T&I 2.3.1": {
   "title": "AI-Native Team Experiments: Deploy initiatives across 3 full cloud environments to test AI-driven team transformation and collaborative experimentation, institutionalizing successful patterns by Q4 to achieve a ≥[X]% uplift in collective productivity and outco",
   "owner": "Jackie Chambers de Freitas + LT of teams in experiments (TBD)",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M2"
  },
  "T&I 3.1": {
   "title": "Security Risk Governance and Autonomous Defense",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M3"
  },
  "T&I 3.1.1": {
   "title": "Drive Measurable Buy-Down of Top Security Risks - Clouds",
   "owner": "Melissa Cazalet, Ajith Jayamohan",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M3"
  },
  "T&I 3.1.2": {
   "title": "Drive Measurable Buy-Down of Top Security Risks - Enterprise",
   "owner": "Evan Davis",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M3"
  },
  "T&I 3.1.3": {
   "title": "Modernize Detection, Response, and Validation Capabilities",
   "owner": "Kelly McCracken Ajith Jayamohan",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M3"
  },
  "T&I 3.1.4": {
   "title": "Project Guardian:",
   "owner": "Herman Kwong",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M3"
  },
  "T&I 3.1.5": {
   "title": "Create Roadmap to address Non-human Identity Audit Findings in Enterprise. Create the framework to discover orphaned/active/unmanaged non-human privileged accounts across enterprise assets, establish governance and secrets management plan. Gain cross-functiona",
   "owner": "Evan Davis",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M3"
  },
  "T&I 3.1.6": {
   "title": "Implement a resilient, highly available Next Generation PKI powered by Keyfactor, improving Enterprise service/application operations through automation & self service certificate lifecycle and the successful migration of FY27 scoped applications off legacy Ac",
   "owner": "Evan Davis",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M3"
  },
  "T&I 3.2": {
   "title": "Establish Secure Design as a Foundational Engineering Discipline Across Salesforce",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M3"
  },
  "T&I 3.2.1": {
   "title": "Paladin: Secure Agentic SDLC",
   "owner": "Melissa Cazalet ",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M3"
  },
  "T&I 3.2.2": {
   "title": "Offensive Security",
   "owner": "Melissa Cazalet",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M3"
  },
  "T&I 3.2.3": {
   "title": "Our commitment to mergers and acquisitions security upholds customer trust and protects customer data, Salesforce products, and the Salesforce enterprise throughout the entire acquisition lifecycle, enabling acquisitions to act as the secure engine of growth f",
   "owner": "Evan Davis",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M3"
  },
  "T&I 3.3": {
   "title": "Deliver a Secure-by-Default Infrastructure with Modernized Substrate and Continuous Autonomous Security Assurance to Protect Customer Trust",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M3"
  },
  "T&I 3.3.1": {
   "title": "By Q2: Complete security architecture and Secure by Default reviews for 100% of foundational and high-priority native GCP services, with all design review reports attached and identified risks logged with assigned owners. Substrate security readiness report de",
   "owner": "Melissa Cazalet",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M3"
  },
  "T&I 3.3.2": {
   "title": "3PP supply chain rigor ready for frontier-level vulnerability and new FedRAMP requirements",
   "owner": "Herman Kwong",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M3"
  },
  "T&I 3.3.3": {
   "title": "Actionable Risk Intelligence",
   "owner": "Kelly McCracken Aasia Haque",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M3"
  },
  "T&I 3.3.4": {
   "title": "Secure Code & Infrastructure",
   "owner": "Tyson Lutz, Ajith Jayamohan",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M3"
  },
  "T&I 3.4": {
   "title": "Maintain & Expand Global Certifications to Enable Market Access and Customer Trust",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M3"
  },
  "T&I 3.4.1": {
   "title": "Maintain 100% on-time certification renewals across all commercial, regulatory and public-sector frameworks",
   "owner": "Alex Kreilein",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M3"
  },
  "T&I 3.4.2": {
   "title": "Expand Salesforce’s global certification footprint:",
   "owner": "Alex Kreilein",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M3"
  },
  "T&I 3.4.3": {
   "title": "Increase audit efficiency and Infrastructure readiness by using agentic automation. Achieve 30% (45/150) CCF baseline controls evidence automatically collected, and tested for efficacy automatically to proactively identify and remediate issues and drive remedi",
   "owner": "Alex Kreilein",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M3"
  },
  "T&I 3.5": {
   "title": "Global Safety & Security",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M3"
  },
  "T&I 3.5.1": {
   "title": "Enable Trust by Protecting our People, Offices, Events, Products and Operational Resilience: Achieve 100% critical control success, 100% Enterprise Resilience Board Objectives, 100% Regulatory Compliance and 95%+ Employees complete ACT GS&S Training requiremen",
   "owner": "Keith White (Security)",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M3"
  },
  "T&I 3.5.2": {
   "title": "Lead and advise on geopolitical, counterintelligence, insider threat matters, and corporate investigations to mitigate and defend against threats from fraud, nation-state actors, criminal enterprises, and foreign adversaries. - Intelligence Products: Provide e",
   "owner": "Keith White (Security) Kelly McCracken ",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M3"
  },
  "T&I 3.6": {
   "title": "Foundation Security",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M3"
  },
  "T&I 3.6.1": {
   "title": "Root-of-Trust, Secrets, and Key Management Transformation",
   "owner": "Fiaz Hossain , Erin Torpey",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M3"
  },
  "T&I 3.6.2": {
   "title": "Strengthen Identity Perimeter",
   "owner": "Claudia Santoro ",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M3"
  },
  "T&I 3.6.3": {
   "title": "Production IAM Architectural Transformation",
   "owner": "Claudia Santoro",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M3"
  },
  "T&I 3.6.4": {
   "title": "Egress Governance to address growing business needs:",
   "owner": "Satish Raghunath ",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M3"
  },
  "T&I 3.6.5": {
   "title": "Enforce account guardrails and drift detection with a API driven PCS orchestration flow that delegates substrate network provisioning and constructs to hyperforce networking for speed of execution and consolidates substrate account lifecycle management, securi",
   "owner": "Claudia Santoro",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M3"
  },
  "T&I 3.6.6": {
   "title": "Prem 360 and 1P DB Data Exfiltration",
   "owner": "Garren Bellew Satish Raghunath Cormac Malone, Ashok Yannam",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M3"
  },
  "T&I 3.6.7": {
   "title": "Non-human Identity Audit Findings",
   "owner": "Claudia Santoro Garren Bellew",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M3"
  },
  "T&I 3.6.8": {
   "title": "100% of production services stream security telemetry to Trust by end of FY and maintain 99% compliance with SFSS-LMI-001.",
   "owner": "Iain Mulholland, Herman Kwong",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M3"
  },
  "T&I 4.1": {
   "title": "Transformation",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M4"
  },
  "T&I 4.1.1": {
   "title": "Developer AI Ecosystem",
   "owner": "Kedar Doshi",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M4"
  },
  "T&I 4.1.2": {
   "title": "AI Engineering Intelligence",
   "owner": "Kedar Doshi",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M4"
  },
  "T&I 4.1.3": {
   "title": "AI Budget Governance",
   "owner": "Kedar Doshi, Shiva Nimmagadda, Nitin T Bhat",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M4"
  },
  "T&I 4.2": {
   "title": "Paved Path & Platform Uplift",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M4"
  },
  "T&I 4.2.1": {
   "title": "Accelerate developer productivity by reducing Core Feedback Loop (P80) from 8+ hours to 3 hours:",
   "owner": "Chris Kohr",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M4"
  },
  "T&I 4.2.2": {
   "title": "Reduce Near-Core cycle time by 20% through staged rollout of AI-powered Salesforce Workspaces & CI:",
   "owner": "Chris Kohr",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M4"
  },
  "T&I 4.2.3": {
   "title": "Accelerate UAP (Data Cloud, AI, Tableau, Analytics) velocity by improving OrgFarm automated provisioning success rate to 75%:",
   "owner": "Shiva Nimmagadda",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M4"
  },
  "T&I 4.2.4": {
   "title": "Improve Scale Loop efficiency and reduce infrastructure spend by cutting OrgFarm provisioning time and costs by 50%:",
   "owner": "Shiva Nimmagadda",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M4"
  },
  "T&I 4.2.5": {
   "title": "Language & Framework (L&F) Maturity & Governance (http://sfdc.co/fy27-languages-and-frameworks )",
   "owner": "Ravinder Ramchandani",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M4"
  },
  "T&I 4.3": {
   "title": "Agentic Intelligence",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M4"
  },
  "T&I 4.3.1": {
   "title": "Provide the right tool for the right job by conducting quarterly tool assessment/evaluation/pulse checks for internal and external AI tooling and make build/buy decisions in a timely manner",
   "owner": "Kedar Doshi",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M4"
  },
  "T&I 4.3.2": {
   "title": "(T&P V2MOM Language)",
   "owner": "Lisa Marshall",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M4"
  },
  "T&I 4.3.3": {
   "title": "(T&P V2MOM Language)",
   "owner": "Alex Hu Shiva Nimmagadda",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M4"
  },
  "T&I 4.3.4": {
   "title": "GUS as AI hub for Trusted Work Collaboration",
   "owner": "Herman Kwong, Henry Hahn",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M4"
  },
  "T&I 4.3.5": {
   "title": "Provide world-class developer support by scaling the HDPS support model through AI-driven automation:",
   "owner": "Mark Biersack Chris Kohr Shiva Nimmagadda",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M4"
  },
  "T&I 4.3.6": {
   "title": "75% reduction in outer loop cycle time - tracking cycle time from feature decision to release",
   "owner": "Shan Appajodu ",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M4"
  },
  "T&I 4.3.7": {
   "title": "Extending Hyperforce Platform for Untrusted Code",
   "owner": "Anubhav Dhoot, Herman Kwong",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M4"
  },
  "T&I 5.1.1": {
   "title": "- P90 TTD ≤ 10 min and P75 TTR ≤ 550mins for Sev0/1s",
   "owner": "Tyson Lutz Ben Hoyt",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M5"
  },
  "T&I 5.1.2": {
   "title": "Highly available and Scalable Core Runtime Platform",
   "owner": "Sriram Dinavahi Olu Obembe, Laksh Venka Amit Kumar Prem Veeramani",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M5"
  },
  "T&I 5.1.2.1": {
   "title": "Help achieve Core app rollback remediation TTR <=15min by improvements to Apex pre-compilation: p80 latency goes from 7 min 30 sec to 3 min 45 sec; track release over release pre-compilation performance to ensure no regressions; define the north star roadmap t",
   "owner": "Igor Pesenson, Susan Putvin",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M5"
  },
  "T&I 5.1.2.2": {
   "title": "Supercell deployments for MQ, Vegacache, and Ingress Gateway to minimize blast radius - prioritize BLT50 [Q4] followed by GTA150 [start in Q4]",
   "owner": "Amit Kumar, Srikanth Rajan",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M5"
  },
  "T&I 5.1.3": {
   "title": "Warden AIOps for T0/T1 HF services with high blast radius to drive 99.99% availability with measurable improvements for TTMD & TTR",
   "owner": "Sriram Dinavahi Laksh Venka, Karishma Lalwani",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M5"
  },
  "T&I 5.1.4": {
   "title": "High Availability Maturity Score (HAMS):",
   "owner": "Ben Hoyt Tyson Lutz, L4 Eng Leaders",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M5"
  },
  "T&I 5.1.5": {
   "title": "1. Chaos testing - all FKP based services chaos tested in Prod0 by Q2.",
   "owner": "Nishant Gupta (CAO)",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M5"
  },
  "T&I 5.1.6": {
   "title": "Capacity-Aware Releases: Deliver capacity-aware release functionality to enable cost-effectively and efficient change rollout, Pilot in Q2, GA by Q4.",
   "owner": " Nitin T Bhat Tyson Lutz Anubhav Dhoot Sriram Dinavahi",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M5"
  },
  "T&I 5.1.7": {
   "title": "Gater Performance and Unification. Achieve high-velocity emergency response in Hyperforce by enabling 5-minute fleet-wide and 2-minute single-target updates for emergency changes by Q2. To sustain this performance and eliminate platform fragmentation, merge 10",
   "owner": "Shan Appajodu Jón Grétarsson",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M5"
  },
  "T&I 5.1.8": {
   "title": "Trust Platform driven Availability Uplift",
   "owner": "Herman Kwong, Yogesh Mehta Achal Khetarpal",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M5"
  },
  "T&I 5.1.9": {
   "title": "FKP ensures tier0/1 stateless services have no more than 10% AZ skew for AZ failure resilience by Q4",
   "owner": "Anubhav Dhoot",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M5"
  },
  "T&I 5.1.10": {
   "title": "Unified Release Process & Platform Standardization",
   "owner": "Shan Appajodu, Bryant Lee, Zhanara Amans",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M5"
  },
  "T&I 5.2": {
   "title": "Restrict cross-FI dependencies",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M5"
  },
  "T&I 5.2.1": {
   "title": "Cross FI traffic is blocked for all new use cases. Soter and Private Linker to restrict all cross-FI traffic for new services, except for pre-approved patterns and CAO approved exceptions, and pilot services for up to 50 customers",
   "owner": "Herman Kwong",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M5"
  },
  "T&I 5.2.2": {
   "title": "Need plan to address all services not currently provisioned in all FIs",
   "owner": "Tyson Lutz Sahil Vazirani",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M5"
  },
  "T&I 5.2.3": {
   "title": "Continually measure and report any code or config drift detected between all Hyperforce instances.",
   "owner": "Tyson Lutz Sahil Vazirani",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M5"
  },
  "T&I 5.3": {
   "title": "Within-FI Blast Radius Reduction & Fault Tolerance",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M5"
  },
  "T&I 5.3.1": {
   "title": "50% reduction in Production FI-level blast radius for individual disruptions of customer-specific traffic for KMS, Vault, PKI, Egress, through the implementation of full stack redundancy, establishing DIY-cellularity of service layers, and segmentation of netw",
   "owner": "Herman Kwong Hetal Sachdeva",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M5"
  },
  "T&I 5.3.2": {
   "title": "FI-level Runtime Fault Tolerance Improvements by eliminating Single Point of Failures (SPoF) or dependency softening during service disruptions for KMS, Vault, PKI, EGW, IAMDS, QuantumK and PLEX. Mitigations for all 8 known STP SPoFs are implemented. IAMDS and",
   "owner": "Herman Kwong Hetal Sachdeva",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M5"
  },
  "T&I 5.3.3": {
   "title": "Global Services Change-Induced Blast Radius Reduction",
   "owner": "Herman Kwong ",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M5"
  },
  "T&I 5.3.4": {
   "title": "Global Single-Point-of-Failures risk reduction",
   "owner": "Herman Kwong Hetal Sachdeva",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M5"
  },
  "T&I 5.3.5": {
   "title": "Deliver OOB Cluster redundancy & Cellularization",
   "owner": "Anubhav Dhoot, Varun Gupta, Mark Biersack",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M5"
  },
  "T&I 5.3.6": {
   "title": "Blast radius by Q4: every Tier 0 deployment or configuration change stays within 10% of its Fault Isolation (FI), and every Tier 1 change within 50%, with a long-term plan for finer-grained, per-customer targeted canarying delivered by end of Q4.",
   "owner": "Tyson Lutz, Ben Hoyt, Sahil Vazirani",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M5"
  },
  "T&I 5.4": {
   "title": "Intelligent Workload Placement",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M5"
  },
  "T&I 5.4.1": {
   "title": "Tenant Mobility:",
   "owner": "Amy Hurlbut",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M5"
  },
  "T&I 5.4.2": {
   "title": "AOV Balancing - All FIs have C360 AOV less than $4B by Q4 FY27.",
   "owner": "Nitin T Bhat Amy Hurlbut",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M5"
  },
  "T&I 5.4.3": {
   "title": "AOV Balancing: Move at least 90% of eligible IND FINS AOV from Prod2 to Prod24 by Q4.",
   "owner": "Nitin T Bhat Amy Hurlbut",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M5"
  },
  "T&I 5.4.4": {
   "title": "AOV Balancing - Balance Core AOV across incremental FIs in each of the following countries: Australia, UK, USA, France, and Germany such that Technology, Financial Services, Manufacturing, and Healthcare AOV is evenly spread across FIs within those four countr",
   "owner": "Nitin T Bhat Amy Hurlbut",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M5"
  },
  "T&I 5.5": {
   "title": "Accelerate Availability",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M5"
  },
  "T&I 5.5.1": {
   "title": "FKP & Integrations Safe Change",
   "owner": "Anubhav Dhoot",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M5"
  },
  "T&I 5.5.2": {
   "title": "Streamline Change Policies and Procedures in partnership with Meir and MK orgs to eliminate outer-loop friction through procedural simplification and tooling enhancements by Q3",
   "owner": "Tyson Lutz",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M5"
  },
  "T&I 6.1": {
   "title": "Core Customer Ramp to Hyperforce",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M6"
  },
  "T&I 6.1.1": {
   "title": "CCR2HF - 100% of Core prod orgs on Hyperforce by EoQ3, except for AWS averse, ACRC-roadmap, and T&P exceptions",
   "owner": "Amy HurlbutSridevi Gopala Krishnan Andrea Loster Soumya Roy",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M6"
  },
  "T&I 6.1.2": {
   "title": "CCR2HF - 10% of AWS-averse prod Core orgs migrated to Hyperforce-GCP by EoFY27, including some orgs from Alphabet and Walmart",
   "owner": "Amy HurlbutSridevi Gopala Krishnan Andrea Loster Soumya Roy",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M6"
  },
  "T&I 6.1.3": {
   "title": "Eligibility - No new downselect for 1P -> HF (GCP & AWS) in FY27 and all services must comply with Core tenant (Org) Mobility requirements",
   "owner": "Amy HurlbutSridevi Gopala Krishnan Andrea Loster Soumya Roy",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M6"
  },
  "T&I 6.1.4": {
   "title": "Eligibility - 100% of legally ineligible customers are eligible for HF migrations by EoQ1",
   "owner": "Amy HurlbutSridevi Gopala Krishnan Andrea Loster Soumya Roy",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M6"
  },
  "T&I 6.1.5": {
   "title": "\"Stagger rollout of org migration from 1P->GCP beginning in June. First external customer migrations in September\"",
   "owner": "Amy HurlbutSridevi Gopala Krishnan Andrea Loster Soumya Roy",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M6"
  },
  "T&I 6.1.6": {
   "title": "Stagger rollout of org migration from AWS->GCP beginning with 264 SB0 in mid-August.",
   "owner": "Amy HurlbutSridevi Gopala Krishnan Andrea Loster Soumya Roy",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M6"
  },
  "T&I 6.1.7": {
   "title": "Non-Revenue Orgs - 90% of eligible non-revenue Core orgs migrated to Hyperforce by EoFY27 (plan)",
   "owner": "Amy HurlbutSridevi Gopala Krishnan Andrea Loster Soumya Roy",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M6"
  },
  "T&I 6.2": {
   "title": "Advanced Cross Region Continuity (ACRC) for Core",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M6"
  },
  "T&I 6.2.1": {
   "title": "To enable certain financial and manufacturing customers to exit 1P, enhance ACRC to have RTO/RPO of 12 hrs/4 hrs by Q1.",
   "owner": "Subho Chatterjee Vijay Devadhar Alberto Valcarlos",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M6"
  },
  "T&I 6.2.2": {
   "title": "To enable a subset of Japan customers to exit 1P, SCRT1 supports ACRC by Q1.",
   "owner": "Subho Chatterjee Vijay Devadhar Alberto Valcarlos",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M6"
  },
  "T&I 6.2.3": {
   "title": "To enable a subset of Japan customers to exit 1P, SCRT2 services support ACRC by Q4.",
   "owner": "Subho Chatterjee , Yacov Salomon, Vijay Devadhar , Alberto Valcarlos",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M6"
  },
  "T&I 6.2.4": {
   "title": "Deliver ACRC compliance for identified SKUs by Q4, including:",
   "owner": "Subho Chatterjee, Vijay Devadhar , Alberto Valcarlos",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M6"
  },
  "T&I 6.2.5": {
   "title": "Make ACRC available in new countries and regions",
   "owner": "Manish Chandra, Subho Chatterjee , Vijay Devadhar , Alberto Valcarlos",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M6"
  },
  "T&I 6.3": {
   "title": "Ecom to Hyperforce",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M6"
  },
  "T&I 6.3.1": {
   "title": "100 realms (~5% of storefronts) migrated before the holiday moratorium (November 2026)",
   "owner": "Amy Hurlbut Shailesh Kumar Nick Martz",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M6"
  },
  "T&I 6.3.2": {
   "title": "Support 40 realm/month migration velocity by end of FY",
   "owner": "Amy Hurlbut Shailesh Kumar Nick Martz",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M6"
  },
  "T&I 6.4": {
   "title": "Hyperforce New Region Expansion",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M6"
  },
  "T&I 6.4.1": {
   "title": "100% of new Hyperforce FIs supporting 1P Exit meet their planned first migration dates:",
   "owner": "Tyson Lutz Manish Chandra Pallavi Chauhan",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M6"
  },
  "T&I 6.4.2": {
   "title": "100% of new Hyperforce FIs supporting FI Rebalancing meet their planned first migration dates:",
   "owner": "Tyson Lutz Manish Chandra Pallavi Chauhan",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M6"
  },
  "T&I 6.4.3": {
   "title": "100% of new Hyperforce FIs supporting New Regions meet their planned first migration dates:",
   "owner": "Tyson Lutz Manish Chandra Pallavi Chauhan",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M6"
  },
  "T&I 6.5": {
   "title": "1P Restructuring Achievement",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M6"
  },
  "T&I 6.5.1": {
   "title": "Consolidate first-party footprint from 140 to 65 pods by Q4 FY27, advancing toward the target of 50 pods in Q1 FY28. This consolidation will generate $77M in total restructuring savings: $19M in FY27, $42M in FY28, and $16M in FY29",
   "owner": "Amy Hurlbut George Yao Pallavi Chauhan Katie Wakim Pallavi Chauhan",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M6"
  },
  "T&I 6.6": {
   "title": "1P Decomm",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M6"
  },
  "T&I 6.6.1": {
   "title": "Complete all scheduled 1P decommissions by their FY27 deadlines to reduce cost and risk.",
   "owner": "Alsontra Daniels, Tyson Lutz, Katie Wakim Jason Pollack",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M6"
  },
  "T&I 6.7": {
   "title": "Dynamic Org Placement",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M6"
  },
  "T&I 6.7.1": {
   "title": "Migrations - By the end of FY27, 75% of intra-FD migrations executed in 15-min communicated read-only windows, 60% of signup conversion migrations completed in <30s, and technical roadmap validated to scale intra-FD core org migrations to 100% <30s execution i",
   "owner": "Amy HurlbutIntisar Malhi Haiyan Du Raksha Subramanyam Charlotte Doud",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M6"
  },
  "T&I 6.8": {
   "title": "Hyperforce Core Infrastructure Consolidation",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M6"
  },
  "T&I 6.8.1": {
   "title": "Evacuate & decommission 31 obsolete Core cells within their FD to ensure efficient fleet utilization as infrastructure and workload placement evolve",
   "owner": "Amy HurlbutKatie Fuller Suresh Subramanian Xinwei Jin Raksha Subramanyam Charlotte Doud",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M6"
  },
  "T&I 6.8.2": {
   "title": "Decomm Prod3/Core2eoz FD to drive upwards of $160K/month CTS Savings by end of Q4.",
   "owner": "Amy HurlbutKatie Fuller Suresh Subramanian Xinwei Jin Raksha Subramanyam Charlotte Doud",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M6"
  },
  "T&I 7.1": {
   "title": "Hyperforce Paved Path Availability",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M7"
  },
  "T&I 7.1.1": {
   "title": "Hyperforce Foundation developer experience for effective delivery of paved paths in AWS Commercial,GIA2H,GCP",
   "owner": "Paul Constantinides, Shan Appajodu , Tyson Lutz",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M7"
  },
  "T&I 7.1.2": {
   "title": "Hyperforce Paved Paths available in AWS Commercial, GIA2H, and GCP. Versioned paved paths deployed all environments consistently, declared timeline for versioned deployment per environment. Build automation consistently deployed in all environments.",
   "owner": "Paul Constantinides, Shan Appajodu ",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M7"
  },
  "T&I 7.1.3": {
   "title": "\"Make GIA2H releases safe change compliant. Deliver:",
   "owner": "Shan Appajodu , Tyson Lutz ",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M7"
  },
  "T&I 7.1.4": {
   "title": "Make GIA2H Day 2 operations safe change compliant. Produce a multi-release roadmap plan (by EoQ1) to deliver an in-boundary implementation of Managed Operations, SFMP and Warden AIOps (on par with commercial Hyperforce) and execute against the plan in FY27.",
   "owner": "Shan Appajodu, Sriram Dinavahi, Scott Yancey",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M7"
  },
  "T&I 7.1.5": {
   "title": "Make GIA2H observability and testing aligned with commercial Hyperforce. Produce a multi-release roadmap plan and execute against this plan in FY27.",
   "owner": "Sanjeev Lakshmanan, Gautam Bhatia",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M7"
  },
  "T&I 7.1.6": {
   "title": "Accelerate Near Core products like Agentforce, SCRT2, Thunderbird by providing managed caching, queuing, enhanced traffic routing, observability, rate limiting, near-core authN/Z capabilities and tenant aware egress callouts for near-core by Q4",
   "owner": "Anubhav Dhoot , Amy Hurlbut",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M7"
  },
  "T&I 7.1.7": {
   "title": "License Consumption Score (LCS)",
   "owner": "Jim Wiese",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M7"
  },
  "T&I 7.1.8": {
   "title": "Agentforce and Data Cloud Adoption and Engagement Metrics",
   "owner": "Jim Wiese",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M7"
  },
  "T&I 7.2": {
   "title": "GCP",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M7"
  },
  "T&I 7.2.1": {
   "title": "GCP EGL Core Availability: Achieve External Go Live ( EGL ) by 7/1/2026 General Availability (GA) for North America Core substrate by Nov 2026",
   "owner": "Anubhav Dhoot Achal Khetarpal",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M7"
  },
  "T&I 7.2.2": {
   "title": "SCRT1 and SCRT2 EGL and GA in GCP",
   "owner": "Anubhav Dhoot , Tara Earhart, Subho Chatterjee , Yacov Salomon",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M7"
  },
  "T&I 7.2.3": {
   "title": "All product Clouds ( Sales, Service, Platform) complete product cloud testing and issue fixes by 6/1; All Foundation and Core service complete Q4 testing and fix performance regressions by 6/15",
   "owner": "Anubhav Dhoot Pawan Lalwani",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M7"
  },
  "T&I 7.2.4": {
   "title": "Security scanners available and fully operational in GCP Prod by EGL (7/1 target)",
   "owner": "Anubhav Dhoot",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M7"
  },
  "T&I 7.2.5": {
   "title": "GCP Pilot and Org Migration Support Run Pilot and validations with SBXs/ Prod Orgs (internal and external) Jul-Oct 2026 before GA",
   "owner": "Anubhav Dhoot",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M7"
  },
  "T&I 7.2.6": {
   "title": "100% of Hyperforce Paved Path adoption in GCP in FY27, no service will be onboarded to GCP if not 100% adopting Hyperforce Paved Path.",
   "owner": "Anubhav Dhoot",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M7"
  },
  "T&I 7.2.7": {
   "title": "All global release and support teams extend release and operational processes to include GCP by 7/1/2026, especially CCE, CIR, SRE (CP-SR), CAPE, Change Management, Release Management, GRE",
   "owner": "Tyson Lutz",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M7"
  },
  "T&I 7.3": {
   "title": "Blackjack-J Classified ATO with Core",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M7"
  },
  "T&I 7.3.1": {
   "title": "Deliver Remaining Core, Platform, and Hyperforce Services to Blackjack J Prod (Q2)",
   "owner": "Jim Wiese",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M7"
  },
  "T&I 7.3.2": {
   "title": "Accreditation: Submit for ATO (Authority To Operate) by June 2026 (Est. 3 Month Approval Timeline to Follow)",
   "owner": "Jim Wiese",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M7"
  },
  "T&I 7.4": {
   "title": "GovCloud Ops & Networking (Required for Various Operations - Link)",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M7"
  },
  "T&I 7.4.1": {
   "title": "Deliver UIP in GovCloud (GIA2H) - providing a production-grade analytics platform for GIA2H:",
   "owner": "Paul Constantinides, Kurt Brown",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M7"
  },
  "T&I 7.4.2": {
   "title": "Deliver IPv6 support for GIA2H Civilian enabling customer incoming and outgoing connections with IPv6 endpoints.",
   "owner": "Herman Kwong Sajith Thirunilathil",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M7"
  },
  "T&I 7.5": {
   "title": "Agentforce on GCP",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M7"
  },
  "T&I 7.5.1": {
   "title": "GCP C360 Product Expansion: POC, Plan, and Deliver according to business priorities - Complete Data Cloud design by Q1 - Data Cloud exit dev in Q1'28 - Complete Agentforce/Einstein design by Q1'27 - Agentforce/Einstein exit dev in Q2'28, ECOM commerce cloud on",
   "owner": "Anubhav Dhoot Raveendrnathan Loganathan",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M7"
  },
  "T&I 7.6": {
   "title": "Convergence of Existing Substrates",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M7"
  },
  "T&I 7.6.1": {
   "title": "Deliver Hyperforce on GCP-specific uplift back to Hyperforce on AWS to drive alignment across the Hyperforce fleet.",
   "owner": "Shan Appajodu, Anubhav Dhoot, Herman Kwong",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M7"
  },
  "T&I 7.6.2": {
   "title": "Complete an assessment of all Falcon services in Q2 identifying hard-coded logic in configuration and deployment code that will not be eliminated in FY27 by the adoption of substrate agnostic addons and Managed Pipelines. Develop a remediation plan in Q3 and e",
   "owner": "Shan Appajodu",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M7"
  },
  "T&I 7.6.3": {
   "title": "Enable GaterX gate execution targets based upon Hyperforce operating zone name by end of Q3, leveraging the Core/Near-Core operating zone framework. Drive adoption of GaterX with OZ based targets by 100% of services by Q4.",
   "owner": "Shan Appajodu",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M7"
  },
  "T&I 7.6.4": {
   "title": "Operating Zone (OZ) Metadata API for Core",
   "owner": "Brian Toal, Sriram Dinavahi",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M7"
  },
  "T&I 7.6.5": {
   "title": "Deliver a plan for tenant-aware platform capabilities that leverage tenant characteristics to intelligently route requests to appropriate infrastructure, services, and resources—enabling GIA2H Defense and DHA tenants with distinct requirements to share a Hyper",
   "owner": "Herman Kwong, Anubhav Dhoot",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M7"
  },
  "T&I 7.6.6": {
   "title": "Implement OrgFarm on Hyperforce in FY27 and deliver to Hyperforce commercial and in-boundary implementations to GIA2H and Blackack J",
   "owner": "Shiva Nimmagadda",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M7"
  },
  "T&I 7.7": {
   "title": "AliCloud Business Growth",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M7"
  },
  "T&I 7.7.1": {
   "title": "100M+ MNC revenue protection (including IHG, Mariott, GM, Volta) with Loyalty Cloud Customer live preview in China by EoFY, enabled with DPE on CRMA, Flowsnake, Capstone.",
   "owner": "Claudia Santoro",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M7"
  },
  "T&I 8.1": {
   "title": "Proactively drive customer implementation health by integrating signals from tools such as Trust360, Scale Center , ProM and MyTrust to drive targeted resolution working in collaboration with CSG",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M8"
  },
  "T&I 8.1.1": {
   "title": "Trust360 Report via CSM Led Motion for all Signature customers",
   "owner": "Karishma Lalwani, Krishna Chalamasandra, Laksh Venka, Anand Vardhan, Lokesh Bangalore",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M8"
  },
  "T&I 8.1.2": {
   "title": "Top 1000 Signature success Customers",
   "owner": "Kent Allison",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M8"
  },
  "T&I 8.1.3": {
   "title": "My Trust Center Launches in April 2026 with support for core production and Marketing Cloud Engagement with Patch Release support.",
   "owner": "John Maxey",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M8"
  },
  "T&I 8.1.4": {
   "title": "Scale Test for KEM Offer",
   "owner": "Mayuresh Verma, Archana Sethuraman",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M8"
  },
  "T&I 8.1.5": {
   "title": "Automate THR (Technical Health Review) experience for signature customers to improve Support productivity",
   "owner": "Karishma Lalwani, Laksh Venka, Usha Natarajan",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M8"
  },
  "T&I 8.2": {
   "title": "Improve Support Productivity by automating causation and insights to drive faster MTTR",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M8"
  },
  "T&I 8.2.1": {
   "title": "Deliver an agentic troubleshooting solution for Support engineers that bridges them with Service Owners’ telemetry and signals, enabling faster troubleshooting and precise escalation.",
   "owner": "Utpal Das, Vineeli Uppaluri, Rohit Sahana",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M8"
  },
  "T&I 8.2.2": {
   "title": "Integrate Scale Agent with In-App help agent",
   "owner": "Kent Allison, Utpal Das",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M8"
  },
  "T&I 8.3": {
   "title": "Shift left and integrate with developer workflows and establish quality gates",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M8"
  },
  "T&I 8.3.1": {
   "title": "- Deliver ApexGuru and Scale Insights via MCP to surface runtime insights directly in Agentforce Vibes, Cursor, GitHub Copilot, Windsurf, and Slack, enabling developers to fix performance issues faster without context switching.",
   "owner": "Mayuresh Verma, Manpreet Singh",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M8"
  },
  "T&I 8.3.2": {
   "title": "Scale Test for Gov Cloud, GCP , Industries",
   "owner": "Mayuresh Verma, Archana Sethuraman",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M8"
  },
  "T&I 8.3.3": {
   "title": "Vibe Testing for functional and Scale Testing to deliver test script automations",
   "owner": "Mayuresh Verma, Archana Sethuraman",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M8"
  },
  "T&I 8.4": {
   "title": "Agentic AI to empower customers (self service) to own their responsibility to develop scalable solutions",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M8"
  },
  "T&I 8.4.1": {
   "title": "- GA Scale Agent for Org Summary and recommendations [TDX]",
   "owner": "Mayuresh Verma, Utpal Das Ravi Raina",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M8"
  },
  "T&I 8.5": {
   "title": "Proactive Alerting on critical health signals to our Signature customers beyond Core CRM for our C360 Apps",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M8"
  },
  "T&I 8.5.1": {
   "title": "- Slack (deliver first 13 alerts aligned with CSG Success Plan GA)",
   "owner": "Kent Allison, Auro Dharmapuram, Rohit Sahana",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M8"
  },
  "T&I 8.6": {
   "title": "ProM alerts expansion for all customers",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M8"
  },
  "T&I 8.6.1": {
   "title": "- (262) Support for 10K tenants, 50 alert definitions per tenant, 1 minute evaluation cycles",
   "owner": "Sukumar MaddineniPaymon Teyer, Laurent Pautet",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M8"
  },
  "T&I 8.6.2": {
   "title": "- (264) Deliver fault-isolated Alert evaluation environment",
   "owner": "Sukumar MaddineniPaymon Teyer, Laurent Pautet",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M8"
  },
  "T&I 8.7": {
   "title": "Top Customer level CTS Improvements",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M8"
  },
  "T&I 8.7.1": {
   "title": "Org Cost to Serve Visibility",
   "owner": "Sriram Dinavahi Brian Toal Clay Reynolds",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M8"
  },
  "T&I 9.1": {
   "title": "Capacity Management",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M9"
  },
  "T&I 9.1.1": {
   "title": "Deliver HF Build and Destroy continuous integration (CI) for all products by Q4 FY27. All automation defects will be logged onto Service Owners.",
   "owner": "Tyson Lutz",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M9"
  },
  "T&I 9.1.2": {
   "title": "All product FD builds are completed (request to Customer Go Live) within 17 days by Q4 FY27:",
   "owner": "Tyson Lutz",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M9"
  },
  "T&I 9.1.3": {
   "title": "New regional FI expansion builds are completed within 20 days by Q4 FY27.",
   "owner": "Tyson Lutz",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M9"
  },
  "T&I 9.1.4": {
   "title": "Enable 100% automated ephemeral environments (inflate/deflate) for Tableau, Mulesoft, Einstein, Data 360 test environments by Q4 FY27",
   "owner": "Tyson Lutz",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M9"
  },
  "T&I 9.1.5": {
   "title": "Deliver monthly automated predictive cost and capacity forecasts for Hyperforce Services by Q3, and maintain adherence to 95%+ forecast accuracy SLOs",
   "owner": "Kyle Gilson Anton Kirilov",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M9"
  },
  "T&I 9.1.6": {
   "title": "Ensure no revenue-potential signup cells breach DB CPU or org-count thresholds across FY27.",
   "owner": "Katie Fuller",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M9"
  },
  "T&I 9.2": {
   "title": "Cost and Budget",
   "owner": "",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M9"
  },
  "T&I 9.2.1": {
   "title": "Achieve AWS Savings Plan utilization and coverage ≥97%",
   "owner": "Naresh Kumar",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M9"
  },
  "T&I 9.2.2": {
   "title": "Realize 100% of cloud credits (AWS and GCP) by FY27 close.",
   "owner": "Naresh Kumar",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M9"
  },
  "T&I 9.2.3": {
   "title": "Maintain unused ODCR <10% monthly and suspend or pre-empt (internal spot market) ≥35% of unused ODCR by Q4 FY27",
   "owner": "Naresh Kumar Anton Kirilov Katie Wakim",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M9"
  },
  "T&I 9.2.4": {
   "title": "Ensure every L5 manager with >$1M annual spend maintains a COIN score ≥85 by Q4 FY27, strengthening local cost ownership and behavior.",
   "owner": "George Parker + All eng leaders",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M9"
  },
  "T&I 9.2.5": {
   "title": "Reduce total pre-production environment cost by $20M by Q4 FY27 through environment consolidation and utilization optimization, with no regression to release-qualification coverage or quality gates.",
   "owner": "Nitin T Bhat",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M9"
  },
  "T&I 9.2.6": {
   "title": "Implement safe continuous Kubernetes right-sizing automation on FKP on pre-prod by Q3 FY27 and select prod by Q4 FY27",
   "owner": "Anubhav Dhoot",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M9"
  },
  "T&I 9.2.7": {
   "title": "Node optimizations",
   "owner": "Anubhav Dhoot",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M9"
  },
  "T&I 9.2.8": {
   "title": "\"Achieve ≥ 90% forecasting accuracy for organic traffic growth and capacity requirements across Hyperforce products accounting for 80% of the spend by end of Q3 FY27\"",
   "owner": "Kyle Gilson",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M9"
  },
  "T&I 9.2.9": {
   "title": "Deliver monthly Unit Cost and CTS reporting for all major clouds — Core, CDP, Tableau, Agentforce, GovCloud, MuleSoft, and Slack — by the end of FY26.",
   "owner": "George Parker",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M9"
  },
  "T&I 9.2.10": {
   "title": "Improve automated 12-month financial runway models for all product families with enhanced driver management, achieving 95%+ quarterly accuracy across both ML-generated and Budget Owner driver-based financial forecasts by end of year",
   "owner": "Kyle Gilson",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M9"
  },
  "T&I 9.2.11": {
   "title": "Reduce “zero-customer infrastructure footprint” by ≥ 20% by Q4 FY27 across HF.",
   "owner": "Nitin T Bhat Tyson Lutz+ Key service leaders",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M9"
  },
  "T&I 9.2.12": {
   "title": "Implement showback for Monitoring and UIP by Q2 FY27.",
   "owner": "Sanjeev Lakshmanan",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M9"
  },
  "T&I 9.2.13": {
   "title": "Get to <5% of spend without service level tagging on all HF resources. (incl. in GovCloud)",
   "owner": "Shan Appajodu, Herman Kwong",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M9"
  },
  "T&I 9.2.14": {
   "title": "Establish Developer tooling (incl. AI) cost transparency with monthly reporting by Q2 FY27.",
   "owner": "Shiva Nimmagadda",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M9"
  },
  "T&I 9.2.15": {
   "title": "Reduce “Idle” compute spend (sam_reserved) on default nodepools by Q4 by reducing idle waste to 20% on target clusters (~$15M/year). Enable service owners with dedicated nodepools to reduce idle ratio to 20% (~$18M/year).",
   "owner": "Anubhav Dhoot",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M9"
  },
  "T&I 9.2.16": {
   "title": "Capture 37% of the identified $280k/week low p99 CPU util savings opportunity across HRP platform services through right-sizing or approved COIN logic change requests by Q4.",
   "owner": "Anubhav Dhoot Shan Appajodu ",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M9"
  },
  "T&I 9.2.17": {
   "title": "Achieve 100% cost attribution for “Idle” compute spend for non-FKP managed nodepools to their respective owners.",
   "owner": "Anubhav Dhoot",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M9"
  },
  "T&I 9.2.18": {
   "title": "Drive non-Java Oracle usage to 0 across Salesforce (T&P, DET and across substrates) by May 2028.",
   "owner": "Nitin T Bhat",
   "xref": "",
   "label": "T&I FY27 V2MOM (Meir)",
   "tab": "M9"
  }
 }
};
