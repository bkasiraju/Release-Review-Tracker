'use strict';
const {randomUUID}=require('crypto');const {URL}=require('url');
const {parseComments,mergeComments,plainText,validMonth}=require('./comments');
const reviewPolicy=require('./review-policy');
const {parseEpicLinks,validId,safeError}=require('./gus');
function yearValue(y){y=Number(y);if(!Number.isInteger(y)||y<2000||y>2099)throw Error('Reference year must be between 2000 and 2099.');return y;}
function publicParsed(p){const latestMonths={},monthEntries={};for(const section of p.sections||[]){const key=section.effectiveMonth||section.month;if(!key)continue;(monthEntries[key]||=[]).push(section.text);if(!Object.hasOwn(latestMonths,key))latestMonths[key]=section.text;}return {months:p.months,latestMonths,monthEntries,unassigned:p.unassigned,inferred:p.inferred,yearAmbiguous:p.yearAmbiguous};}
const LEAN_COLUMNS=['project','months','pathToGreen','completion'];
function listDefaults(columns=[]){const have=new Set(columns.map(c=>c.key));return [...new Set([...LEAN_COLUMNS.filter(k=>!columns.length||have.has(k)||k==='months'),'health'])];}
const CANON_COLUMNS=['project','name','owner','health','reviewStatus','months','pathToGreen','completion','planned','actual','closed','inProgress','newPoints','waiting','lead','team'];
function releaseScope(r){const lists=Array.isArray(r.sources)?r.sources.map(s=>s?.id).filter(id=>typeof id==='string'&&/^(?:00B|aBQ)[A-Za-z0-9]{12}(?:[A-Za-z0-9]{3})?$/.test(id)).map(id=>id.slice(0,15)).sort():[];const manual=[];if(lists.length)for(const token of String(r.inputLinks||'').replace(/\[[^\]]*\]\((https:\/\/[^)\s]+)\)/g,'$1').split(/[\s,]+/).filter(Boolean)){let id=null;if(/^[A-Za-z0-9]{15}(?:[A-Za-z0-9]{3})?$/.test(token)&&!token.startsWith('00B')&&!token.startsWith('aBQ'))id=token;else if(token.includes('://')){try{const path=new URL(token).pathname,idMatch=path.match(/^\/lightning\/r\/ADM_Epic__c\/([A-Za-z0-9]{15}(?:[A-Za-z0-9]{3})?)\/view\/?$/)||path.match(/^\/([A-Za-z0-9]{15}(?:[A-Za-z0-9]{3})?)\/?$/);if(idMatch)id=idMatch[1];}catch{}}if(id)manual.push(id.slice(0,15));}return JSON.stringify([lists.length?['lists',...new Set(lists)]:String(r.name||'').trim().replace(/\s+/g,' ').toLowerCase(),r.year,lists.length?[...new Set(manual)].sort():[...(r.epicIds||[])].sort(),lists.length?null:String(r.inputLinks||'').trim().replace(/\s+/g,' ').toLowerCase()]);}
function activeReleases(rows){const deleted=new Set(rows.filter(r=>r._deleted).flatMap(r=>r._deletedAliases||[r.id]));return rows.filter(r=>!r._deleted&&!deleted.has(r.id));}
class Service{
  constructor(store,gus,options={}){this.store=store;this.gus=gus;this.shared=options.shared===true;this.googleSheets=options.googleSheets;this.readOnly=options.readOnly===true;}
  async state(){const [catalog,epics]=await Promise.all([this.store.list('release'),this.store.list('epic')]);const releases=activeReleases(catalog);releases.sort((a,b)=>String(b.updatedAt||'').localeCompare(String(a.updatedAt||'')));return {v2momReference:await this.reviewReference(),releases,epics:epics.map(e=>({...e,parsed:publicParsed(this.parsed(e)),pathToGreen:plainText(e.pathToGreen)}))};}
  async release(id){if(typeof id!=='string'||!/^[a-f0-9-]{36}$/.test(id))throw Error('Select a saved release.');const r=await this.store.get('release',id);if(!r)throw Error('Release not found. Reload the dashboard.');if(r._deleted)throw Error('This release was deleted. Reload the dashboard.');const catalog=await this.releaseCatalog();if(!activeReleases(catalog).some(x=>x.id===id))throw Error('This release was deleted. Reload the dashboard.');return r;}
  async releaseCatalog(){return this.store.list('release');}
  async deleteRelease(data){
    const r=await this.release(data.releaseId);if(data.revision!==r.revision)throw Error('This release changed. Reload before deleting.');
    if(data.confirmation!==r.name)throw Error('Confirm the exact release name before deleting.');
    const aliases=(await this.releaseCatalog()).filter(x=>!x._deleted&&releaseScope(x)===releaseScope(r));
    const results=[];for(let i=0;i<aliases.length;i+=4){results.push(...await Promise.all(aliases.slice(i,i+4).map(async old=>{try{await this.store.put('release',old.id,{...old,_deleted:true,_deletedAliases:aliases.map(x=>x.id),_deletedAt:new Date().toISOString()},old.revision);return {id:old.id,deleted:true};}catch(error){return {id:old.id,deleted:false,error:safeError(error)};}})));}
    if(!results.some(x=>x.deleted))throw Error(results[0]?.error||'Could not delete this release.');
    return {results};
  }
  async saveRelease(data){
    const name=String(data.name||'').trim();if(!name||name.length>100)throw Error('Enter a release name (up to 100 characters).');
    const old=data.id?await this.release(data.id):null;
    const year=yearValue(data.year),inputLinks=String(data.links??'').trim();const resolved=typeof this.gus.resolveEpicInputs==='function'?await this.gus.resolveEpicInputs(inputLinks):{ids:parseEpicLinks(inputLinks),sources:[],columns:[]};const ids=resolved.ids;const id=data.id||randomUUID();
    if(old&&data.revision!==old.revision)throw Error('This release changed. Reload before saving.');
    const months=(data.months??old?.months??[]);if(!Array.isArray(months)||months.length>120)throw Error('Use up to 120 review months.');months.forEach(validMonth);
    const sourceChanged=JSON.stringify(old?.sourceColumns||[])!==JSON.stringify(resolved.columns);const columnMode=data.columns?'custom':old?.columnMode==='custom'&&!sourceChanged?'custom':'gus';const columns=data.columns??(columnMode==='custom'?old.columns:listDefaults(resolved.columns));
    const allowedColumns=new Set([...CANON_COLUMNS,...resolved.columns.map(c=>c.key)]);
    if(columns!==null&&(!Array.isArray(columns)||columns.some(c=>typeof c!=='string'||!allowedColumns.has(c))))throw Error('Invalid column settings. Choose a supported dashboard or source-list column.');
    const value={id,name,year,epicIds:ids,inputLinks,sources:resolved.sources,sourceColumns:resolved.columns,columnMode,months:[...new Set(months)],hiddenMonths:old?.hiddenMonths||[],visibleMonths:old?.visibleMonths,detailStatusColumns:old?.detailStatusColumns||[],columns,_storageConflicts:data.resolveStorage?[]:(old?._storageConflicts||[])};return this.store.put('release',id,value,old?data.revision:null);
  }
  // Planned Release → review release. Reuses the release already tracking that planned release, else creates one that
  // keeps the dashboard's current column order.
  async usePlannedRelease(data){
    const pid=String(data.plannedId||'');if(!/^aBQ[A-Za-z0-9]{12}(?:[A-Za-z0-9]{3})?$/.test(pid))throw Error('Choose a planned release.');
    const key=pid.slice(0,15),rows=activeReleases(await this.releaseCatalog()).sort((a,b)=>String(b.updatedAt||'').localeCompare(String(a.updatedAt||'')));
    const have=rows.find(r=>(r.sources||[]).some(x=>x?.id===key));if(have)return have;
    const template=rows.find(r=>Array.isArray(r.columns)&&r.columns.length),canon=new Set(CANON_COLUMNS);
    const columns=template?template.columns.filter(c=>canon.has(c)):undefined;
    const name=String(data.name||'').trim()||'Planned release',year=Number(String(data.start||'').slice(0,4))||new Date().getFullYear();
    return this.saveRelease({name,year,links:'https://gus.lightning.force.com/lightning/r/ADM_Planned_Release__c/'+pid+'/view',columns:columns&&columns.length?columns:undefined});
  }
  async reviewDefaults(){const doc=await this.store.get('settings','review-defaults');return {map:doc?.map&&typeof doc.map==='object'?doc.map:{}};}
  async setReviewDefault(data){
    if(this.readOnly)throw Error('Sample preview is read-only.');
    const team=String(data.teamId||'');if(!/^[a-zA-Z0-9]{15,18}$/.test(team))throw Error('Choose a team first.');
    const cur=await this.store.get('settings','review-defaults'),map={...(cur?.map||{})};
    if(data.releaseId){await this.release(data.releaseId);map[team]=data.releaseId;}else delete map[team];
    await this.store.put('settings','review-defaults',{map},cur?cur.revision:null);return {map};
  }
  async executive(data){
    const id=validId(data.epicId),month=validMonth(data.month),r=await this.release(data.releaseId);if(!r.epicIds.includes(id))throw Error('Epic is not part of this release.');
    const [result,stored]=await Promise.all([this.gus.epics([id],[{field:'Project__r.Name',key:'gus:Project__r.Name'}]),this.store.get('epic',id)]);const row=result.epics[0];if(!row)throw Error('Epic is not visible in GUS.');
    const epic={...stored,...row,year:stored?.year??r.year,yearMapping:stored?.yearMapping||{}};return require('./executive').healthSource(epic,this.parsed(epic),month);
  }
  async monthlySummary(data){
    const id=validId(data.epicId),month=validMonth(data.month),r=await this.release(data.releaseId);if(!r.epicIds.includes(id))throw Error('Epic is not part of this release.');
    if(data.previewOnly===true&&(typeof data.displayedText!=='string'||data.displayedText.length>50000))throw Error('Monthly preview supports up to 50,000 characters.');
    const columns=reviewPolicy.FIELDS;
    const [result,work,old]=await Promise.all([this.gus.epics([id],columns),this.gus.workItems(id,{details:true,month}),this.store.get('epic',id)]),row=result.epics[0];if(!row)throw Error('Epic is not visible in GUS.');
    const e={...old,...row,year:old?.year??r.year,yearMapping:old?.yearMapping||{}};const mapping={measure:e.project||e.extra?.['Project__r.Name']||null,method:null,source:'GUS epic context'};if(data.previewOnly!==true)reviewPolicy.assertReady(e,{mapping,requireMeasure:false,requirePath:false,text:this.parsed(e).months[month]||''});e.v2momMapping=mapping;let parsed=this.parsed(e);if(data.previewOnly===true){parsed={...parsed,months:{...parsed.months,[month]:data.displayedText},sections:[{month,effectiveMonth:month,text:data.displayedText},...(parsed.sections||[]).filter(s=>(s.effectiveMonth||s.month)!==month)]};}const health=require('./executive').healthSource(e,parsed,month);
    return {epicId:id,month,...await require('./monthly').monthlyDraft(this.gus.sf,{epic:e,health,work,month},{prepare:data.useSdk===true,previewOnly:data.previewOnly===true})};
  }
  async executivePlan(data){
    validMonth(data.month);
    if(!Array.isArray(data.releaseIds)||!data.releaseIds.length||data.releaseIds.length>100)throw Error('Choose releases before generating a summary.');
    const catalog=activeReleases(await this.releaseCatalog()),releases=data.releaseIds.map(id=>{const r=catalog.find(r=>r.id===id);if(!r)throw Error('Release no longer available. Refresh and retry.');return r;});
    const ids=[...new Set(releases.flatMap(r=>r.epicIds))],groups=new Map(),blocked=[];
    if(ids.length>500)throw Error('Choose releases containing up to 500 unique epics.');
    for(let start=0;start<ids.length;start+=50){const batch=ids.slice(start,start+50),result=await require('./summary-cache').snapshots(this,batch,releases,data.month);
      for(const id of result.missing||[])blocked.push({epicId:id,name:id,error:'Epic is not visible to you in GUS (check your access or refresh the release).'});
      for(const e of result.epics){try{const mapping={measure:e.project||e.extra?.['Project__r.Name']||null,method:null};reviewPolicy.assertReady(e,{mapping,requireMeasure:false,requirePath:false,text:this.parsed({...e,year:releases.find(r=>r.epicIds.includes(e.id)).year}).months[data.month]||''});}catch(error){blocked.push({epicId:e.id,name:e.name,error:safeError(error)});continue;}const measure=e.project||e.extra?.['Project__r.Name']||'Measure not set in GUS',team=e.team||'Team not set in GUS',key=JSON.stringify([measure,team]);if(!groups.has(key))groups.set(key,{measure,team,epicIds:[]});groups.get(key).epicIds.push(e.id);}
    }
    return {blocked,groups:[...groups.values()].flatMap(g=>g.epicIds.map(id=>({...g,epicIds:[id]})))};
  }
  async executiveBlurb(data){
    const month=validMonth(data.month);if(!Array.isArray(data.releaseIds)||!data.releaseIds.length||data.releaseIds.length>100||!Array.isArray(data.epicIds)||!data.epicIds.length||data.epicIds.length>500)throw Error('Choose a supported release scope for the executive update.');
    const catalog=activeReleases(await this.releaseCatalog()),releases=data.releaseIds.map(id=>{const r=catalog.find(r=>r.id===id);if(!r)throw Error('Release no longer available. Refresh and retry.');return r;});
    const ids=[...new Set(data.epicIds.map(validId))];if(ids.some(id=>!releases.some(r=>r.epicIds.includes(id))))throw Error('Epic is not part of the selected releases.');
    const sources=[];const {healthSource,summarizeGroup}=require('./executive');
    for(let start=0;start<ids.length;start+=50){const batch=ids.slice(start,start+50);const [result,saved]=await Promise.all([require('./summary-cache').snapshots(this,batch,releases,month),typeof this.store.getMany==='function'?this.store.getMany('epic',batch):Promise.all(batch.map(async id=>[id,await this.store.get('epic',id)])).then(entries=>new Map(entries))]);
      if(result.epics.length!==batch.length)throw Error('An epic in this update is not visible to you in GUS. Check your access or refresh the release.');
      for(const row of result.epics){const old=saved.get(row.id),r=releases.find(r=>r.epicIds.includes(row.id)),e={...old,...row,year:old?.year??r.year,yearMapping:old?.yearMapping||{}};const mapping={measure:e.project||e.extra?.['Project__r.Name']||null,method:null};reviewPolicy.assertReady(e,{mapping,requireMeasure:false,requirePath:false,text:this.parsed(e).months[month]||''});const source={...healthSource(e,this.parsed(e),month),commentRevision:require('./summary-cache').hash([e.comments,e.health]),measure:mapping.measure||'Measure not set in GUS',mapping,goal:reviewPolicy.goalOf(e),pathToGreen:plainText(e.pathToGreen),completion:e.completion,plannedEnd:e.extra?.Planned_End_Date__c,actual:e.actual,closed:e.closed};if(source.measure!==data.measure||source.team!==data.team)throw Error('The GUS measure or team changed. Fetch the latest data and regenerate.');const work=await require('./summary-cache').work(this,row.id,month,row.fetchedAt);if(work.truncated||work.historyTruncated)throw Error('Delivery evidence is incomplete for '+row.name+'. No partial executive update was generated.');const scope=require('./monthly').monthlyWork(work,month);source.work=scope.primary.map(w=>({subject:w.title,description:w.description||w.details,statusAtReview:w.periodStatus??null,sprint:w.sprint}));sources.push(source);}
    }
    const payload={health:sources[0]?.health,kpis:{completion:sources[0]?.completion,plannedEnd:sources[0]?.plannedEnd,actual:sources[0]?.actual,closed:sources[0]?.closed},pathToGreen:sources[0]?.pathToGreen,callouts:[...sources.filter(s=>!s.updates?.some(u=>u.month===month)).map(()=> 'No dated engineer update for the review month; historical context is labeled separately.'),...sources.filter(s=>!s.mapping?.measure).map(()=> 'Measure is not set in GUS; this update is not assigned to a V2MOM measure.')],measure:data.measure,team:data.team,epicId:sources.length===1?sources[0].epicId:null,epicName:sources.length===1?sources[0].name:null,...await summarizeGroup(this.gus.sf,sources,{prepare:true}),reportedMonths:[...new Set(sources.flatMap(s=>s.reportedMonths||[]))].sort(),hasUndated:sources.some(s=>!!s.undated),generatedAt:new Date().toISOString()};
    const cached=await require('./summary-cache').prepare(this,data,sources,payload);if(cached.cacheHit||data.useSdk===true)return cached;const native={...cached,...await summarizeGroup(this.gus.sf,sources)};delete native.ai;if(native.draftReady&&cached.cacheTicket)try{return await require('./summary-cache').save(this,{...data,ticket:cached.cacheTicket,blurb:native.blurb,mode:native.mode});}catch{/* Keep valid generated text if cache persistence is unavailable. */}return native;
  }
  async reviewReference(){const saved=await this.store.get('settings','v2mom');return {value:saved?.v2mom||reviewPolicy.DEFAULT_REFERENCE,revision:saved?.revision||null};}
  async saveReference(data){const current=await this.store.get('settings','v2mom');if((current?.revision||null)!==(data.revision||null))throw Error('The V2MOM reference changed. Reload before saving.');const saved=await this.store.put('settings','v2mom',{id:'v2mom',v2mom:reviewPolicy.reference(data.value)},current?.revision||null);return {value:saved.v2mom,revision:saved.revision};}
  async mapping(epic){try{return await reviewPolicy.mappedEpic(epic,async()=>{if(!this.mappingSnapshot)this.mappingSnapshot=this.reviewReference().then(r=>reviewPolicy.liveMapping(r.value,this.googleSheets));return this.mappingSnapshot;});}catch(error){const saved=await this.store.get('epic',epic.id),confirmed=saved?.v2momConfirmed,ref=await this.reviewReference();if(confirmed&&!confirmed.none&&confirmed.measure?.trim()&&confirmed.referenceKey===JSON.stringify(ref.value))return {measure:confirmed.none?'No V2MOM mapping — confirmed by engineer':confirmed.measure,method:confirmed.none?'None — confirmed by engineer':confirmed.method,source:'Engineer confirmed',callout:'Project/sheet mapping was unavailable or unresolved; using the engineer-confirmed measure.'};throw error;}}
  async saveMapping(data){const id=validId(data.epicId),r=await this.release(data.releaseId);if(!r.epicIds.includes(id))throw Error('Epic is not part of this release.');const old=await this.store.get('epic',id);if(!old||old.revision!==data.revision)throw Error('Epic changed. Refresh before confirming mapping.');const ref=await this.reviewReference(),none=false;if(typeof data.measure!=='string'||!data.measure.trim()||data.measure.length>500)throw Error('Enter the V2MOM Measure. Method is optional.');const saved=await this.store.put('epic',id,{...old,v2momConfirmed:{none,measure:none?'':data.measure.trim(),method:typeof data.method==='string'?data.method.trim().slice(0,500):'',fiscalYear:ref.value.fiscalYear,referenceUrl:ref.value.url,referenceKey:JSON.stringify(ref.value),confirmedAt:new Date().toISOString()}},old.revision);return {...saved,parsed:publicParsed(this.parsed(saved))};}

  async policyEpic(id){const result=await this.gus.epics([id],reviewPolicy.FIELDS);if(!result.epics[0])throw Error('Epic is not visible in GUS.');return result.epics[0];}
  async savePath(data){const id=validId(data.epicId),r=await this.release(data.releaseId);if(!r.epicIds.includes(id))throw Error('Epic is not part of this release.');if(typeof data.value!=='string'||!data.value.trim()||data.value.length>30000)throw Error('Enter a Path to Green of up to 30,000 characters.');const old=await this.store.get('epic',id);if(!old||old.revision!==data.revision)throw Error('Epic changed. Refresh before editing Path to Green.');const row=await this.gus.epic(id);if(plainText(row.pathToGreen)!==plainText(old.pathToGreen))throw Error('Path to Green changed in GUS. Refresh before saving.');await this.gus.updatePathToGreen(id,data.value.trim(),row.modified);const verified=await this.gus.epic(id);if(plainText(verified.pathToGreen)!==plainText(data.value.trim()))throw Error('GUS Path to Green could not be verified. Refresh before retrying.');const latest=await this.store.get('epic',id);const saved=await this.store.put('epic',id,{...latest,...verified,extra:{...latest.extra,...verified.extra}},latest.revision);return {...saved,parsed:publicParsed(this.parsed(saved)),pathToGreen:plainText(saved.pathToGreen)};}
  async saveEpicStatus(data){
    const id=validId(data.epicId),r=await this.release(data.releaseId);if(!r.epicIds.includes(id))throw Error('Epic is not part of this release.');
    const old=await this.store.get('epic',id);if(!old||old.revision!==data.revision)throw Error('Epic changed. Refresh before editing Epic Status.');
    const options=await this.gus.epicStatusOptions();if(typeof data.value!=='string'||!options.some(o=>o.value===data.value))throw Error('Choose a valid GUS Epic Status.');
    const row=await this.gus.epic(id);if(row.health!==old.health||row.health!==data.previousStatus)throw Error('Epic Status changed in GUS. Refresh before saving.');
    if(data.value==='Watch'&&!plainText(row.pathToGreen).trim())throw Error('Enter and save Path to Green before changing Epic Status to Watch.');
    if(row.health!==data.value)await this.gus.updateEpicStatus(id,data.value,row.modified);
    const verified=await this.gus.epic(id);if(verified.health!==data.value)throw Error('GUS Epic Status could not be verified. Refresh before retrying.');
    const latest=await this.store.get('epic',id),saved=await this.store.put('epic',id,{...latest,...verified,drafts:latest.drafts||{},extra:{...latest.extra,...verified.extra},reviewStatus:row.health===data.value?latest.reviewStatus:undefined,fetchedAt:new Date().toISOString()},latest.revision);
    return {...saved,parsed:publicParsed(this.parsed(saved)),pathToGreen:plainText(saved.pathToGreen)};
  }
  async saveReviewStatus(data){
    const id=validId(data.epicId),r=await this.release(data.releaseId);if(!r.epicIds.includes(id))throw Error('Epic is not part of this release.');
    const old=await this.store.get('epic',id);if(!old||data.revision!==old.revision)throw Error('Epic changed. Refresh before saving Review Status.');
    let row=await this.gus.epic(id);const status=String(row.health||'').trim().toLowerCase(),key=status==='cancelled'?'canceled':status;
    if(key!==data.epicStatus)throw Error('Epic Status changed in GUS. Refresh before choosing Review Status.');
    const choices={watch:['Delayed','At-Risk'],canceled:['De-Prioritised','Mistakenly Added','Not a Priority'],'not started':['Planned','Bandwidth Constraints','Dependency-Blocker','To be re-prioritised']}[key];
    if(!choices||typeof data.value!=='string'||(data.value!==''&&!choices.includes(data.value)))throw Error('Choose a Review Status valid for the current Epic Status.');
    if(data.recoveryText!==undefined){
      validMonth(data.month);if(key!=='watch'||typeof data.recoveryText!=='string'||!data.recoveryText.trim()||data.recoveryText.length>30000)throw Error('Enter a Path to Green of up to 30,000 characters for this Watch epic.');
      const recovery=data.recoveryText.trim();if(plainText(row.pathToGreen)!==plainText(old.pathToGreen)&&plainText(row.pathToGreen)!==plainText(recovery))throw Error('Path to Green changed in GUS. Refresh before saving.');
      const parsed=publicParsed(this.parsed({...old,...row})),current=parsed.latestMonths?.[data.month]||parsed.months?.[data.month]||'',entry='Path to Green:\n'+recovery,value=current.endsWith(entry)?current:[current,entry].filter(Boolean).join('\n\n'),comments=mergeComments(row.comments,old.year,{[data.month]:value});
      await this.gus.updateRecovery(id,recovery,comments,row.modified);const verified=await this.gus.epic(id);if(plainText(verified.pathToGreen)!==plainText(recovery)||plainText(verified.comments)!==plainText(comments))throw Error('Both GUS recovery fields could not be verified. Your text is retained; refresh before retrying.');if(verified.health!==row.health)throw Error('Epic Status changed during the recovery save. Refresh before choosing Review Status.');row=verified;
    }
    if(key==='watch'&&!plainText(row.pathToGreen).trim())throw Error('Enter and save Path to Green before saving Review Status for a Watch epic.');
    const latest=await this.store.get('epic',id);if(latest.revision!==old.revision)throw Error('The shared epic changed during this save. Refresh to review the verified GUS update.');
    const saved=await this.store.put('epic',id,{...old,...row,extra:{...old.extra,...row.extra},drafts:old.drafts||{},reviewStatus:{value:data.value,epicStatus:key,updatedAt:new Date().toISOString()},_storageConflicts:(old._storageConflicts||[]).filter(c=>c.path!=='reviewStatus')},old.revision);
    return {...saved,parsed:publicParsed(this.parsed(saved)),pathToGreen:plainText(saved.pathToGreen)};
  }

  async saveSettings(data){
    const r=await this.release(data.releaseId);
    if(data.revision!==r.revision)throw Error('This release changed. Reload its latest settings before saving.');
    const patch={};
    if(data.columns!==undefined){const allowed=new Set([...CANON_COLUMNS,...(r.sourceColumns||[]).map(c=>c.key)]);
      if(!Array.isArray(data.columns)||data.columns.some(c=>typeof c!=='string'||!allowed.has(c)))throw Error('Invalid column settings. Choose supported dashboard columns.');
      patch.columns=[...new Set([...data.columns,'name','health'])];patch.columnMode=data.columnMode==='gus'?'gus':'custom';if(patch.columnMode==='gus')patch.columns=listDefaults(r.sourceColumns||[]);
    }
    if(data.detailStatusColumns!==undefined){if(!Array.isArray(data.detailStatusColumns)||data.detailStatusColumns.some(k=>!['health','reviewStatus'].includes(k)))throw Error('Choose supported detail status columns.');patch.detailStatusColumns=[...new Set(data.detailStatusColumns)];}
    if(data.months!==undefined){if(!Array.isArray(data.months)||data.months.length>120)throw Error('Use up to 120 review months.');data.months.forEach(validMonth);patch.months=[...new Set(data.months)];}
    if(data.visibleMonths!==undefined){if(!Array.isArray(data.visibleMonths)||data.visibleMonths.length>120)throw Error('Use up to 120 visible months.');data.visibleMonths.forEach(validMonth);patch.visibleMonths=[...new Set(data.visibleMonths)];}
    if(data.hiddenMonths!==undefined){if(!Array.isArray(data.hiddenMonths)||data.hiddenMonths.length>120)throw Error('Use up to 120 hidden months.');data.hiddenMonths.forEach(validMonth);patch.hiddenMonths=[...new Set(data.hiddenMonths)];}
    if(!Object.keys(patch).length)throw Error('Choose columns or review months to save.');
    return this.store.put('release',r.id,{...r,...patch},r.revision);
  }
  async cachedRefreshTime(r){
    if(!r.epicIds.length)return r.lastGusRefreshAt||null;
    const times=[];for(let start=0;start<r.epicIds.length;start+=100){const ids=r.epicIds.slice(start,start+100),rows=typeof this.store.getMany==='function'?await this.store.getMany('epic',ids):new Map(await Promise.all(ids.map(async id=>[id,await this.store.get('epic',id)])));for(const id of ids){const time=Date.parse(rows.get(id)?.fetchedAt);if(!Number.isFinite(time))return null;times.push(time);}}
    return new Date(Math.min(...times)).toISOString();
  }
  async finishFetch(data){
    const r=await this.release(data.releaseId);if(data.fetchRevision!==r.revision)throw Error('Release changed during fetch. Start Fetch again.');
    const time=r.epicIds.length?await this.cachedRefreshTime(r):new Date().toISOString();if(!time)throw Error('Some epics were not saved. Retry Fetch before marking the release refreshed.');
    return this.store.put('release',r.id,{...r,lastGusRefreshAt:time},r.revision);
  }
  async fetch(releaseId,page=null){
    let r=await this.release(releaseId);
    if(page?.automatic===true&&page.cursor===undefined){const cachedAt=await this.cachedRefreshTime(r),refreshedAt=cachedAt?new Date(Math.min(Date.parse(cachedAt),Date.parse(r.lastGusRefreshAt||cachedAt))).toISOString():null,age=Date.now()-Date.parse(refreshedAt);if(refreshedAt&&age>=0&&age<3600000)return {cached:true,results:[],nextCursor:null,total:0,fetchRevision:r.revision,release:r};}
    if((!page||page.cursor===undefined)&&r.sources?.length){const resolved=await this.gus.resolveEpicInputs(r.inputLinks);const sourceChanged=JSON.stringify(r.sourceColumns||[])!==JSON.stringify(resolved.columns),columnMode=r.columnMode==='custom'&&!sourceChanged?'custom':'gus',columns=columnMode==='custom'?r.columns:listDefaults(resolved.columns);if(JSON.stringify([r.epicIds,r.sources,r.sourceColumns,r.columns,r.columnMode])!==JSON.stringify([resolved.ids,resolved.sources,resolved.columns,columns,columnMode]))r=await this.store.put('release',r.id,{...r,epicIds:resolved.ids,sources:resolved.sources,sourceColumns:resolved.columns,columns,columnMode},r.revision);}
    if(page&&page.cursor===undefined&&!r.epicIds.length)r=await this.finishFetch({releaseId:r.id,fetchRevision:r.revision});
    if(page&&page.cursor===undefined)return {results:[],nextCursor:r.epicIds.length?0:null,fetchRevision:r.revision,total:r.epicIds.length,release:r};
    if(page&&(!Number.isInteger(page.cursor)||page.cursor<0||page.cursor>=r.epicIds.length||page.fetchRevision!==r.revision))throw Error('Release changed during fetch. Start Fetch again.');
    if(!r.epicIds.length)return {results:[],nextCursor:null};
    const ids=page?r.epicIds.slice(page.cursor,page.cursor+1):r.epicIds;
    const {epics}=await this.gus.epics(ids,r.sourceColumns||[]);const results=[];
    for(const id of ids){const row=epics.find(e=>e.id===id);if(!row){results.push({epicId:id,status:'error',error:'Epic not found or not visible. Check the link and GUS sharing.'});continue;}
      try{const old=await this.store.get('epic',id);const saved=await this.store.put('epic',id,{...old,...row,extra:{...old?.extra,...row.extra},year:old?.year??r.year,yearConfirmed:old?.yearConfirmed??false,yearMapping:old?.yearMapping??{},drafts:old?.drafts??{},fetchedAt:new Date().toISOString()},old?.revision??null);results.push({epicId:id,status:'fetched',name:saved.name,epic:{...saved,parsed:publicParsed(this.parsed(saved)),pathToGreen:plainText(saved.pathToGreen)}});}
      catch(e){results.push({epicId:id,status:'error',error:safeError(e)});}
    }
    return {results,...(page?{nextCursor:page.cursor+1<r.epicIds.length?page.cursor+1:null,fetchRevision:r.revision,total:r.epicIds.length}:{})};
  }
  async saveDraft(data){
    const id=validId(data.epicId),month=validMonth(data.month);if(typeof data.value!=='string'||data.value.length>50000)throw Error('Monthly updates support up to 50,000 characters.');
    let r=null;
    if(data.releaseId){r=await this.release(data.releaseId);if(!r.epicIds.includes(id))throw Error('Epic is not part of this release.');}
    if(data.autoSync===true&&(!r||typeof data.base!=='string'||data.base.length>50000))throw Error('A release and displayed monthly baseline are required.');
    let e=await this.store.get('epic',id);
    if(!e){if(!r)throw Error('Fetch this epic before editing.');const row=await this.gus.epic(id);e=await this.store.put('epic',id,{...row,year:r.year,yearConfirmed:false,yearMapping:{},drafts:{},fetchedAt:new Date().toISOString()},null);}
    if(data.requestId!==undefined&&(typeof data.requestId!=='string'||!/^[a-f0-9-]{36}$/.test(data.requestId)))throw Error('Invalid save request.');
    const prior=e.drafts?.[month];
    if(data.autoSync===true&&data.requestId&&prior?.requestId===data.requestId&&prior.autoSync&&prior.releaseId===r.id&&prior.value===data.value.trim()&&prior.base===data.base&&!(e._storageConflicts||[]).some(c=>c.path==='drafts.'+month))return e;
    if((prior?.revision??null)!==(data.revision??null))throw Error('This monthly draft changed in another window. Reload before saving.');
    const storageConflicts=e._storageConflicts||[];
    if(storageConflicts.some(c=>c.path==='drafts.'+month)&&!data.resolveStorage)throw Error('This month has competing saved drafts. Resolve them from Review & sync.');
    if(data.resolveStorage&&data.epicRevision!==e.revision)throw Error('Saved drafts changed again. Reload and review the conflict.');
    let baseline=prior?.base??(data.autoSync===true?data.base:this.parsed(e).months[month])??'';
    if(data.resolve){const remote=await this.gus.epic(id);baseline=this.parsed({...e,comments:remote.comments}).months[month]??'';if(typeof data.expectedRemote!=='string'||baseline!==data.expectedRemote)throw Error('This GUS month changed again. Preview the latest conflict before resolving.');}
    const drafts={...e.drafts};
    if(data.discard)delete drafts[month];else drafts[month]={value:data.value.trim(),base:baseline,revision:randomUUID(),updatedAt:new Date().toISOString(),...(data.autoSync===true?{autoSync:true,releaseId:r.id,...(data.requestId?{requestId:data.requestId}:{})}:{})};
    return this.store.put('epic',id,{...e,drafts,_storageConflicts:data.resolveStorage?storageConflicts.filter(c=>c.path!=='drafts.'+month):storageConflicts},e.revision);
  }
  async publishMonth(data){
    const id=validId(data.epicId),month=validMonth(data.month),r=await this.release(data.releaseId);
    if(!r.epicIds.includes(id))throw Error('Epic is not part of this release.');
    const e=await this.store.get('epic',id),draft=e?.drafts?.[month];
    if(!draft||draft.revision!==data.draftRevision)throw Error('This monthly draft changed. Reload before retrying.');
    if(this.shared&&(!draft.requestId||data.requestId!==draft.requestId||data.value!==draft.value))throw Error('Review and approve this shared draft before publishing it in a new session.');
    const releases=activeReleases(await this.store.list('release'));
    const item=await this.buildItem({...e,drafts:{[month]:draft}},releases,month);
    if(item.status!=='ready')return {...item,month};
    const recheck=await this.store.get('epic',id);if(recheck?.drafts?.[month]?.revision!==draft.revision)throw Error('This monthly draft changed before publication. Reload before retrying.');
    let write={conditional:true};
    if(item.consolidated!==item.remote.comments)write=await this.gus.updateComments(id,item.consolidated,item.remote.modified);
    const verified=await this.readComments(id);
    if(verified.comments!==item.consolidated)throw Error('GUS save could not be verified. Your saved monthly update is retained.');
    const latest=await this.store.get('epic',id),drafts={...latest.drafts};
    if(drafts[month]?.revision===draft.revision)delete drafts[month];
    const saved=await this.store.put('epic',id,{...latest,...verified,drafts,lastSyncedAt:new Date().toISOString()},latest.revision);
    return {status:'synced',epicId:id,month,conditional:write.conditional,epic:{...saved,parsed:publicParsed(this.parsed(saved))}};
  }
  async readComments(id){return typeof this.gus.comments==='function'?this.gus.comments(id):this.gus.epic(id);}
  parsed(e){
    const p=parseComments(e.comments,e.year);for(const section of p.sections)section.effectiveMonth=section.inferred?(e.yearMapping?.[section.month]||section.month):section.month;
    if(e.yearMapping&&Object.keys(e.yearMapping).length){
      const months={};for(const s of p.sections){const key=s.inferred?(e.yearMapping[s.month]||s.month):s.month;months[key]=[months[key],s.text].filter(Boolean).join('\n\n');}p.months=months;
    }
    return p;
  }
  async setYear(data){
    const id=validId(data.epicId),e=await this.store.get('epic',id);if(!e)throw Error('Fetch this epic first.');
    if(data.revision!==e.revision)throw Error('This epic changed. Reload before confirming years.');
    const year=yearValue(data.year);if(Object.keys(e.drafts||{}).length&&year!==e.year)throw Error('Discard pending drafts before changing the reference year.');
    const mapping=data.mapping||{};for(const [a,b] of Object.entries(mapping)){validMonth(a);validMonth(b);if(a.slice(5)!==b.slice(5))throw Error('Year mapping must preserve the month.');}
    return this.store.put('epic',id,{...e,year,yearConfirmed:true,yearMapping:mapping,_storageConflicts:(e._storageConflicts||[]).filter(c=>c.path.startsWith('drafts.'))},data.revision);
  }
  async buildItem(e,releases,onlyMonth=null){
    if(e._storageConflicts?.length)return {epicId:e.id,name:e.name,status:'draft-conflict',error:'Competing saved changes require review.',conflicts:e._storageConflicts.map(c=>({month:c.path.startsWith('drafts.')?c.path.slice(7):null,remote:c.previous?.value??JSON.stringify(c.previous),local:c.incoming?.value??JSON.stringify(c.incoming),storage:true,path:c.path}))};
    const policyEpic=await this.policyEpic(e.id),mapping={measure:policyEpic.project||policyEpic.extra?.['Project__r.Name']||null,method:null,source:'GUS epic context'};reviewPolicy.assertReady(policyEpic,{mapping,requireMeasure:false,text:Object.values(e.drafts||{}).map(d=>d.value).join(' ')});
    const remote=await this.readComments(e.id),p=this.parsed({...e,comments:remote.comments}),drafts=e.drafts||{};
    const years=new Set(releases.filter(r=>r.epicIds.includes(e.id)).map(r=>r.year));
    const needsYear=(p.inferred.length&&years.size>1&&!e.yearConfirmed)||
      (p.yearAmbiguous&&!p.inferred.every(m=>Object.hasOwn(e.yearMapping||{},m)));
    if(needsYear)return {epicId:e.id,name:e.name,status:'year-conflict',error:'Confirm years for undated GUS headings before syncing.',remote,months:p.months,inferred:p.inferred};
    const conflicts=[];
    for(const [month,d] of Object.entries(drafts)){const current=p.months[month]??'';if(current!==d.base&&current!==d.value&&p.sections.find(s=>s.month===month)?.text!==d.value)conflicts.push({month,base:d.base,remote:current,local:d.value,revision:d.revision});}
    // Canonicalize inferred headings only when the user supplied a year mapping.
    // Map each original heading independently, retaining surrounding rich text.
    let source=remote.comments;
    const status=String(policyEpic.health||'').trim().toLowerCase().replace('cancelled','canceled'),allowed={watch:['Delayed','At-Risk'],canceled:['De-Prioritised','Mistakenly Added','Not a Priority'],'not started':['Planned','Bandwidth Constraints','Dependency-Blocker','To be re-prioritised']}[status];if(allowed&&!(e.reviewStatus?.epicStatus===status&&allowed.includes(e.reviewStatus.value)))throw Error('Review Status is required for '+policyEpic.health+' epics before publishing.');
const changes=Object.fromEntries(Object.entries(drafts).map(([m,d])=>[m,d.value]));
    const consolidated=mergeComments(source,e.year,changes);
    return {epicId:e.id,name:e.name,status:conflicts.length?'conflict':'ready',conflicts,months:p.months,consolidated,preview:plainText(consolidated),remote,epicRevision:e.revision,draftRevisions:Object.fromEntries(Object.entries(drafts).map(([m,d])=>[m,d.revision]))};
  }
  async preview(releaseId,epicId=null){const r=await this.release(releaseId),releases=activeReleases(await this.store.list('release')),items=[];
    if(epicId&&!r.epicIds.includes(validId(epicId)))throw Error('Epic is not part of this release.');
    for(const id of epicId?[epicId]:r.epicIds){const e=await this.store.get('epic',id);if(!e||!Object.keys(e.drafts||{}).length)continue;try{items.push(await this.buildItem(e,releases));}catch(err){items.push({epicId:id,name:e.name,status:'error',error:safeError(err)});}}
    return {items};
  }
  async sync(releaseId,approved){
    const r=await this.release(releaseId),releases=activeReleases(await this.store.list('release')),results=[];
    for(const id of r.epicIds){if(approved&&!approved.some(a=>a.epicId===id))continue;const e=await this.store.get('epic',id);if(!e||!Object.keys(e.drafts||{}).length)continue;
      try{
        if(approved){const approval=approved.find(a=>a.epicId===id);if(!approval)continue;const versions=Object.fromEntries(Object.entries(e.drafts).map(([m,d])=>[m,d.revision]));if((approval.epicRevision&&approval.epicRevision!==e.revision)||JSON.stringify(Object.entries(versions).sort())!==JSON.stringify(Object.entries(approval.draftRevisions||{}).sort()))throw Error('Drafts changed after preview. Review the latest preview before syncing.');}
        const item=await this.buildItem(e,releases);if(item.status!=='ready'){results.push(item);continue;}
        let write={conditional:true};if(item.consolidated!==item.remote.comments)write=await this.gus.updateComments(id,item.consolidated,item.remote.modified);
        const verified=await this.gus.epic(id);const actual=this.parsed({...e,comments:verified.comments}).months;
        if(verified.comments!==item.consolidated)throw Error('GUS write could not be verified. Drafts are retained. Fetch and preview before retrying.');
        const latest=await this.store.get('epic',id),drafts={...latest.drafts};for(const [month,revision] of Object.entries(item.draftRevisions))if(drafts[month]?.revision===revision)delete drafts[month];
        await this.store.put('epic',id,{...latest,...verified,extra:{...latest.extra,...verified.extra},drafts,year:latest.year,yearConfirmed:latest.yearConfirmed,yearMapping:latest.yearMapping,lastSyncedAt:new Date().toISOString(),fetchedAt:new Date().toISOString()},latest.revision);
        results.push({epicId:id,name:e.name,status:'synced',conditional:write.conditional});
      }catch(err){results.push({epicId:id,name:e.name,status:'error',error:safeError(err)});}
    }
    return {results};
  }
}
module.exports={Service,releaseScope};
